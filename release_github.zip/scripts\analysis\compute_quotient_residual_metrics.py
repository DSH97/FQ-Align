#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats


def minmax_normalize(M, eps=1e-12):
    M = np.asarray(M, dtype=float)
    mask = ~np.eye(M.shape[0], dtype=bool)
    vals = M[mask]
    mn = np.nanmin(vals)
    mx = np.nanmax(vals)
    return (M - mn) / (mx - mn + eps)


def mean_scale_normalize(M, eps=1e-12):
    M = np.asarray(M, dtype=float)
    mask = ~np.eye(M.shape[0], dtype=bool)
    mean_val = np.nanmean(M[mask])
    return M / (mean_val + eps)


def zscore_normalize(M, eps=1e-12):
    M = np.asarray(M, dtype=float)
    mask = ~np.eye(M.shape[0], dtype=bool)
    vals = M[mask]
    mu = np.nanmean(vals)
    sd = np.nanstd(vals)
    return (M - mu) / (sd + eps)


def upper_tri_values(M):
    k = M.shape[0]
    idx = np.triu_indices(k, k=1)
    return M[idx]


def residual_metrics(q_rna, q_atac, name):
    q_rna = np.asarray(q_rna, dtype=float)
    q_atac = np.asarray(q_atac, dtype=float)

    residual = np.abs(q_rna - q_atac)
    diff = q_rna - q_atac

    vals_r = upper_tri_values(q_rna)
    vals_a = upper_tri_values(q_atac)
    vals_res = upper_tri_values(residual)
    vals_diff = upper_tri_values(diff)

    pear = stats.pearsonr(vals_r, vals_a)
    spear = stats.spearmanr(vals_r, vals_a)

    frob = np.linalg.norm(diff, ord="fro")
    denom = np.linalg.norm(q_rna, ord="fro") + np.linalg.norm(q_atac, ord="fro") + 1e-12
    normalized_frob = frob / denom

    mean_abs = float(np.nanmean(vals_res))
    median_abs = float(np.nanmedian(vals_res))
    max_abs = float(np.nanmax(vals_res))
    rmse = float(np.sqrt(np.nanmean(vals_diff ** 2)))

    # Higher is better. This is a bounded residual-derived consistency score.
    # If normalized_frob is 0, score = 1. Larger residuals reduce the score.
    topology_consistency_score = float(1.0 - normalized_frob)

    return {
        "normalization": name,
        "n_states": int(q_rna.shape[0]),
        "n_state_pairs": int(len(vals_res)),
        "mean_abs_quotient_residual": mean_abs,
        "median_abs_quotient_residual": median_abs,
        "max_abs_quotient_residual": max_abs,
        "rmse_quotient_residual": rmse,
        "frobenius_residual": float(frob),
        "normalized_frobenius_residual": float(normalized_frob),
        "residual_based_topology_consistency": topology_consistency_score,
        "pearson_distance_r_auxiliary": float(pear.statistic),
        "pearson_distance_p_auxiliary": float(pear.pvalue),
        "spearman_distance_r_auxiliary": float(spear.statistic),
        "spearman_distance_p_auxiliary": float(spear.pvalue),
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result-dir", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--rna-name", default="quotient_distance_rna.npy")
    parser.add_argument("--atac-name", default="quotient_distance_atac.npy")
    args = parser.parse_args()

    result_dir = Path(args.result_dir)
    q_rna = np.load(result_dir / args.rna_name)
    q_atac = np.load(result_dir / args.atac_name)

    rows = []

    # Raw values: useful if training already normalized quotient distances.
    rows.append(residual_metrics(q_rna, q_atac, "raw"))

    # Recommended for the paper: min-max normalized off-diagonal distances.
    rows.append(residual_metrics(
        minmax_normalize(q_rna),
        minmax_normalize(q_atac),
        "offdiag_minmax"
    ))

    # Optional sensitivity checks.
    rows.append(residual_metrics(
        mean_scale_normalize(q_rna),
        mean_scale_normalize(q_atac),
        "offdiag_mean_scaled"
    ))

    rows.append(residual_metrics(
        zscore_normalize(q_rna),
        zscore_normalize(q_atac),
        "offdiag_zscore"
    ))

    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)

    print(f"[OK] wrote {out}")
    print(pd.DataFrame(rows).to_string(index=False))


if __name__ == "__main__":
    main()