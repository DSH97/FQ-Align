#!/usr/bin/env python3
"""Publication figure for the coherent seed8 state 4-state 10 case."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import umap


COLORS = {
    "B": "#4E79A7",
    "CD4 T": "#F28E2B",
    "CD8 T": "#59A14F",
    "DC": "#E15759",
    "Mono": "#B07AA1",
    "NK": "#9C755F",
    "Unknown": "#BAB0AC",
}
STATE4 = "#2878B5"
STATE10 = "#F28E2B"


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans"],
            "font.size": 7,
            "axes.titlesize": 8,
            "axes.labelsize": 7,
            "axes.linewidth": 0.7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "xtick.labelsize": 6.5,
            "ytick.labelsize": 6.5,
            "legend.fontsize": 6.3,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )


def save_all(fig: plt.Figure, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path.with_suffix(".png"), dpi=500, bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".tiff"), dpi=600, bbox_inches="tight")


def composition_panel(ax: plt.Axes, comp: pd.DataFrame) -> None:
    pivot = (
        comp.pivot(index="state", columns="celltype", values="fraction")
        .fillna(0)
        .reindex(index=[4, 10], fill_value=0)
    )
    bottom = np.zeros(2)
    for label in ["B", "CD4 T", "CD8 T", "DC", "Mono", "NK", "Unknown"]:
        if label not in pivot or np.allclose(pivot[label], 0):
            continue
        ax.bar(
            [0, 1],
            pivot[label].to_numpy(),
            bottom=bottom,
            color=COLORS[label],
            width=0.68,
            label=label,
        )
        bottom += pivot[label].to_numpy()
    ax.set_xticks([0, 1], ["State 4", "State 10"])
    ax.set_ylim(0, 1)
    ax.set_ylabel("Cell fraction")
    ax.set_title("Coarse annotation composition")
    ax.legend(bbox_to_anchor=(1.01, 1), loc="upper left")


def residual_panel(
    ax: plt.Axes, q_rna: np.ndarray, q_atac: np.ndarray
) -> None:
    residual = np.abs(q_rna - q_atac)
    image = ax.imshow(residual, cmap="magma", vmin=0, vmax=np.nanmax(residual))
    for row, col in ((4, 10), (10, 4)):
        ax.add_patch(
            plt.Rectangle(
                (col - 0.5, row - 0.5),
                1,
                1,
                fill=False,
                edgecolor="#00BFC4",
                linewidth=1.4,
            )
        )
    ax.set_xlabel("Fuzzy state")
    ax.set_ylabel("Fuzzy state")
    ax.set_title("Quotient residual geometry")
    cbar = plt.colorbar(image, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label(r"$|Q_{\mathrm{RNA}}-Q_{\mathrm{ATAC}}|$")
    ax.text(
        0.03,
        0.97,
        r"$q_{\mathrm{RNA}}=1.102$" + "\n" + r"$q_{\mathrm{ATAC}}=0.429$",
        transform=ax.transAxes,
        va="top",
        fontsize=6.4,
        color="white",
        bbox={"facecolor": "black", "alpha": 0.45, "edgecolor": "none", "pad": 2},
    )


def expression_panel(ax: plt.Axes, expr: pd.DataFrame) -> None:
    genes = ["NKG7", "GNLY", "GZMA", "CCL5", "PRF1", "CTSW"]
    groups = [
        "State 4, DC-labeled",
        "State 4, NK-labeled",
        "State 10, NK-labeled",
    ]
    colors = [STATE4, "#8EC3E6", STATE10]
    width = 0.24
    x = np.arange(len(genes))
    for offset, group, color in zip((-width, 0, width), groups, colors):
        sub = expr[expr["group"] == group].set_index("gene").reindex(genes)
        ax.bar(
            x + offset,
            sub["pct_gt0"],
            width=width,
            color=color,
            label=f"{group} (n={int(sub['n_cells'].iloc[0])})",
        )
    ax.set_xticks(x, genes, rotation=35, ha="right")
    ax.set_ylim(0, 1)
    ax.set_ylabel("Fraction expressing")
    ax.set_title("Cytotoxic-associated gene detection")
    ax.legend(loc="upper right")


def rna_panel(ax: plt.Axes, de: pd.DataFrame) -> None:
    state4 = de[de["direction"] == "state_4_higher"].head(6)
    state10 = de[de["direction"] == "state_10_higher"].head(6)
    selected = pd.concat([state4, state10]).copy()
    selected = selected.sort_values("logfoldchange")
    colors = [STATE4 if value > 0 else STATE10 for value in selected["logfoldchange"]]
    ax.barh(selected["gene"], selected["logfoldchange"], color=colors)
    ax.axvline(0, color="#333333", linewidth=0.7)
    ax.set_xlabel("Log fold-change (state 4 vs state 10)")
    ax.set_title("RNA marker contrast")


def atac_panel(ax: plt.Axes, bins: pd.DataFrame) -> None:
    state4 = bins[bins["direction"] == "state_4_higher"].head(5)
    state10 = bins[bins["direction"] == "state_10_higher"].head(5)
    selected = pd.concat([state4, state10]).copy().sort_values("effect_size")
    labels = []
    for row in selected.itertuples(index=False):
        linked = str(row.linked_genes) if pd.notna(row.linked_genes) else ""
        labels.append(f"{row.locus_bin}" + (f" ({linked})" if linked else ""))
    colors = [STATE4 if value > 0 else STATE10 for value in selected["effect_size"]]
    ax.barh(labels, selected["effect_size"], color=colors)
    ax.axvline(0, color="#333333", linewidth=0.7)
    ax.set_xlabel("Mean accessibility difference")
    ax.set_title("Differential ATAC bins")


def umap_panel(
    ax: plt.Axes,
    coordinates: np.ndarray,
    cell: pd.DataFrame,
) -> None:
    selected4 = (cell["state"] == 4) & (cell["max_membership"] >= 0.6)
    selected10 = (cell["state"] == 10) & (cell["max_membership"] >= 0.6)
    other = ~(selected4 | selected10)
    ax.scatter(
        coordinates[other, 0],
        coordinates[other, 1],
        s=1.5,
        color="#D9D9D9",
        alpha=0.28,
        linewidth=0,
        rasterized=True,
    )
    ax.scatter(
        coordinates[selected4, 0],
        coordinates[selected4, 1],
        s=5,
        color=STATE4,
        alpha=0.82,
        linewidth=0,
        label=f"State 4 (n={selected4.sum()})",
        rasterized=True,
    )
    ax.scatter(
        coordinates[selected10, 0],
        coordinates[selected10, 1],
        s=5,
        color=STATE10,
        alpha=0.82,
        linewidth=0,
        label=f"State 10 (n={selected10.sum()})",
        rasterized=True,
    )
    ax.set_xlabel("UMAP1")
    ax.set_ylabel("UMAP2")
    ax.set_title("High-confidence cells")
    ax.legend(loc="best", markerscale=2)


def export_panel(
    function,
    output: Path,
    figsize: tuple[float, float],
    *args,
) -> None:
    fig, ax = plt.subplots(figsize=figsize)
    function(ax, *args)
    fig.tight_layout()
    save_all(fig, output)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--case-dir",
        default="../outputs/seed8_main_case_state4_state10",
    )
    parser.add_argument(
        "--seed-dir",
        default="outputs/fqalign_10seeds/seed8",
    )
    args = parser.parse_args()
    configure_style()

    case_dir = Path(args.case_dir)
    seed_dir = Path(args.seed_dir)
    panel_dir = case_dir / "panel_exports"
    panel_dir.mkdir(parents=True, exist_ok=True)

    q_rna = np.load(seed_dir / "quotient_distance_rna.npy")
    q_atac = np.load(seed_dir / "quotient_distance_atac.npy")
    embedding = np.load(seed_dir / "fqalign_embedding.npy")
    cell = pd.read_csv(seed_dir / "cell_modality_reliability.csv")
    comp = pd.read_csv(case_dir / "main_case_celltype_composition.csv")
    expr = pd.read_csv(case_dir / "cytotoxic_expression_group_summary.csv")
    de = pd.read_csv(case_dir / "main_case_rna_differential_genes.csv")
    bins = pd.read_csv(case_dir / "main_case_atac_top_bins_linked_genes.csv")

    umap_path = case_dir / "seed8_umap_coordinates.npy"
    if umap_path.exists():
        coordinates = np.load(umap_path)
    elif (case_dir / "main_case_umap_coordinates.csv").exists():
        cached = pd.read_csv(case_dir / "main_case_umap_coordinates.csv")
        coordinates = cached[["UMAP1", "UMAP2"]].to_numpy(dtype=float)
        np.save(umap_path, coordinates)
    else:
        coordinates = umap.UMAP(
            n_neighbors=30,
            min_dist=0.3,
            metric="cosine",
            random_state=8,
        ).fit_transform(embedding)
        np.save(umap_path, coordinates)

    fig = plt.figure(figsize=(11.4, 6.1))
    grid = fig.add_gridspec(2, 3, width_ratios=[0.95, 1.05, 1.2], hspace=0.42, wspace=0.48)
    axes = [
        fig.add_subplot(grid[0, 0]),
        fig.add_subplot(grid[0, 1]),
        fig.add_subplot(grid[0, 2]),
        fig.add_subplot(grid[1, 0]),
        fig.add_subplot(grid[1, 1]),
        fig.add_subplot(grid[1, 2]),
    ]
    residual_panel(axes[0], q_rna, q_atac)
    composition_panel(axes[1], comp)
    expression_panel(axes[2], expr)
    rna_panel(axes[3], de)
    atac_panel(axes[4], bins)
    umap_panel(axes[5], coordinates, cell)

    for label, ax in zip("abcdef", axes):
        ax.text(
            -0.16,
            1.08,
            label,
            transform=ax.transAxes,
            fontsize=9,
            fontweight="bold",
            va="top",
        )
    save_all(fig, case_dir / "Seed8_state4_state10_main_case")
    plt.close(fig)

    export_panel(residual_panel, panel_dir / "a_residual_geometry", (3.2, 2.9), q_rna, q_atac)
    export_panel(composition_panel, panel_dir / "b_annotation_composition", (3.4, 2.8), comp)
    export_panel(expression_panel, panel_dir / "c_cytotoxic_gene_detection", (4.3, 2.8), expr)
    export_panel(rna_panel, panel_dir / "d_rna_marker_contrast", (3.5, 3.0), de)
    export_panel(atac_panel, panel_dir / "e_atac_bins", (4.2, 3.0), bins)
    export_panel(umap_panel, panel_dir / "f_umap_high_confidence", (3.4, 3.0), coordinates, cell)

    pd.DataFrame(
        {
            "cell": cell["cell"],
            "UMAP1": coordinates[:, 0],
            "UMAP2": coordinates[:, 1],
            "state": cell["state"],
            "max_membership": cell["max_membership"],
            "celltype": cell["celltype"],
        }
    ).to_csv(case_dir / "seed8_umap_source_data.csv", index=False)


if __name__ == "__main__":
    main()
