# benchmark_runtime_memory_safe.py
import os
import time
import psutil
import torch
import pandas as pd
import subprocess
import matplotlib.pyplot as plt
import seaborn as sns

DATASETS = ["PBMC-3K", "PBMC-10K", "SNARE-seq"]
METHODS = ["fqalign", "scglue", "multivi", "cobolt", "mofa"]
DATA_DIR = "./data/processed"
OUT_DIR = "./outputs/benchmark"
EPOCHS = 100

CMD_MAP = {
    "fqalign": "scripts/fuzzy_quotient_align_clean.py",
    "scglue": "scripts/run_scglue_gene_peak.py",
    "multivi": "scripts/run_multivi_clean.py",
    "cobolt": "scripts/run_cobolt_clean.py",
    "mofa": "scripts/run_mofa_clean.py",
}

def get_cpu_mem():
    return psutil.Process(os.getpid()).memory_info().rss / (1024 ** 2)

def get_gpu_mem(device=0):
    if torch.cuda.is_available():
        return torch.cuda.max_memory_allocated(device) / (1024 ** 2)
    return 0

def run_method(method, dataset):
    script = CMD_MAP[method]
    if not os.path.isfile(script):
        script = os.path.join(os.getcwd(), script)
    if not os.path.isfile(script):
        print(f"[SKIP] Script not found: {script}")
        return None, None, None

    out_path = os.path.join(OUT_DIR, method, dataset)
    os.makedirs(out_path, exist_ok=True)

    cmd = ["python", script, "--data-dir", os.path.join(DATA_DIR, dataset),
           "--out-dir", out_path]

    # 添加参数，只加可接受的
    if method in ["fqalign", "scglue", "multivi"]:
        cmd += ["--seed", "0", "--max-epochs", str(EPOCHS)]
    elif method == "cobolt":
        cmd += ["--epochs", str(EPOCHS)]

    print(f"Running {method} on {dataset} ...")
    if torch.cuda.is_available():
        torch.cuda.reset_peak_memory_stats()

    start_cpu = get_cpu_mem()
    start_time = time.time()
    try:
        subprocess.run(cmd, check=True)
    except Exception as e:
        print(f"[ERROR] {method} on {dataset}: {e}")
        return None, None, None

    elapsed = time.time() - start_time
    cpu_mem = get_cpu_mem() - start_cpu
    gpu_mem = get_gpu_mem()
    return elapsed, cpu_mem, gpu_mem

def main():
    results = []
    for dataset in DATASETS:
        for method in METHODS:
            elapsed, cpu_mem, gpu_mem = run_method(method, dataset)
            results.append({
                "dataset": dataset,
                "method": method,
                "runtime_sec": elapsed,
                "cpu_mem_MB": cpu_mem,
                "gpu_mem_MB": gpu_mem
            })

    df = pd.DataFrame(results)
    os.makedirs(OUT_DIR, exist_ok=True)
    csv_path = os.path.join(OUT_DIR, "benchmark_results.csv")
    df.to_csv(csv_path, index=False)
    print(f"CSV saved to {csv_path}")

    # 绘制柱状图
    plt.figure(figsize=(12,5))
    sns.barplot(x="method", y="runtime_sec", hue="dataset", data=df)
    plt.title("Runtime per Method and Dataset (s)")
    plt.ylabel("Time (s)")
    plt.savefig(os.path.join(OUT_DIR, "runtime_barplot.png"), dpi=300)
    plt.close()

    plt.figure(figsize=(12,5))
    df_melt = df.melt(id_vars=["method","dataset"], value_vars=["cpu_mem_MB","gpu_mem_MB"],
                      var_name="Memory Type", value_name="Memory (MB)")
    sns.barplot(x="method", y="Memory (MB)", hue="dataset", data=df_melt)
    plt.title("CPU/GPU Memory per Method and Dataset")
    plt.ylabel("Memory (MB)")
    plt.savefig(os.path.join(OUT_DIR, "memory_barplot.png"), dpi=300)
    plt.close()
    print("Barplots saved.")

if __name__ == "__main__":
    main()