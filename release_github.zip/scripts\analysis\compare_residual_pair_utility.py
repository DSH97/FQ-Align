#!/usr/bin/env python3
"""Compare quotient-residual prioritization with a centroid-distance baseline.

The analysis is post hoc and uses saved FQ-Align outputs. It does not retrain
the model. Pair utility is summarized using quantities that are not direct
components of the quotient residual:

1. fraction of low-membership cells assigned to either state;
2. normalized entropy of the available coarse cell annotations;
3. RNA-versus-ATAC silhouette-score discrepancy;
4. dissimilarity of the states' top RNA marker lists;
5. residual stability across repeated training seeds.

The script also exports a compact summary of the three highest quotient-
residual pairs. Marker-program labels are descriptive gene-set overlaps and
are not treated as cell-type assignments.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from sklearn.metrics import silhouette_score


EPS = 1e-12
PROGRAM_GENES = {
    "cytotoxic": {"NKG7", "GNLY", "GZMA", "GZMB", "PRF1", "CCL5", "CTSW", "KLRD1"},
    "naive_T": {"IL7R", "TCF7", "LEF1", "BCL11B", "CCR7", "LTB", "MAL"},
    "myeloid": {"LYZ", "LST1", "FCN1", "S100A9", "SAT1", "NAMPT", "PLXDC2", "LYN", "VCAN"},
    "DC_like": {"FCER1A", "CLEC10A", "CD74", "HLA-DRA", "HLA-DPB1", "CST3"},
    "B_cell": {"MS4A1", "CD79A", "CD79B", "BANK1", "IGHM", "CD74"},
}


def upper_values(matrix: np.ndarray) -> np.ndarray:
    return matrix[np.triu_indices(matrix.shape[0], k=1)]


def normalize_offdiag_mean(matrix: np.ndarray) -> np.ndarray:
    return matrix / (float(np.mean(upper_values(matrix))) + EPS)


def fuzzy_centroid_distances(x: np.ndarray, membership: np.ndarray) -> np.ndarray:
    mass = membership.sum(axis=0) + EPS
    centroids = membership.T @ x / mass[:, None]
    return normalize_offdiag_mean(cdist(centroids, centroids, metric="euclidean"))


def ranked_pairs(matrix: np.ndarray) -> list[tuple[int, int, float]]:
    pairs = [
        (i, j, float(matrix[i, j]))
        for i, j in combinations(range(matrix.shape[0]), 2)
    ]
    return sorted(pairs, key=lambda row: row[2], reverse=True)


def normalized_entropy(labels: pd.Series) -> float:
    labels = labels.fillna("Unknown").astype(str).replace({"nan": "Unknown"})
    probabilities = labels.value_counts(normalize=True).to_numpy(dtype=float)
    if len(probabilities) <= 1:
        return 0.0
    entropy = -np.sum(probabilities * np.log(probabilities + EPS))
    return float(entropy / np.log(len(probabilities)))


def parse_markers(path: Path) -> dict[int, list[str]]:
    df = pd.read_csv(path)
    if {"state", "top_genes"}.issubset(df.columns):
        return {
            int(row.state): [
                gene.strip() for gene in str(row.top_genes).split(",") if gene.strip()
            ]
            for row in df.itertuples(index=False)
        }
    if {"state", "rank", "gene"}.issubset(df.columns):
        df = df.sort_values(["state", "rank"])
        return {
            int(state): sub["gene"].astype(str).tolist()
            for state, sub in df.groupby("state")
        }
    if {"group", "gene", "score"}.issubset(df.columns):
        df = df.sort_values(["group", "score"], ascending=[True, False])
        return {
            int(float(state)): sub["gene"].astype(str).tolist()
            for state, sub in df.groupby("group")
        }
    raise ValueError(f"Unsupported marker table schema: {list(df.columns)}")


def marker_program_hits(genes: list[str], top_n: int = 20) -> dict[str, int]:
    selected = set(genes[:top_n])
    return {
        program: len(selected.intersection(program_genes))
        for program, program_genes in PROGRAM_GENES.items()
    }


def format_program_hits(hits: dict[str, int], minimum_hits: int = 2) -> str:
    retained = [(program, count) for program, count in hits.items() if count >= minimum_hits]
    retained.sort(key=lambda item: item[1], reverse=True)
    return "; ".join(f"{program}:{count}" for program, count in retained) or "no program with >=2 hits"


def state_composition(labels: pd.Series, states: np.ndarray, state: int) -> str:
    values = (
        labels[states == state]
        .fillna("Unknown")
        .astype(str)
        .replace({"nan": "Unknown"})
        .value_counts(normalize=True)
    )
    return "; ".join(f"{label}:{fraction:.3f}" for label, fraction in values.items())


def safe_pair_silhouette(
    embedding: np.ndarray,
    assigned_states: np.ndarray,
    state_i: int,
    state_j: int,
) -> float:
    mask = np.isin(assigned_states, [state_i, state_j])
    pair_labels = assigned_states[mask]
    if mask.sum() < 4 or len(np.unique(pair_labels)) != 2:
        return np.nan
    counts = pd.Series(pair_labels).value_counts()
    if counts.min() < 2:
        return np.nan
    return float(silhouette_score(embedding[mask], pair_labels, metric="euclidean"))


def build_pair_metrics(
    membership: np.ndarray,
    labels: pd.Series,
    rna_embedding: np.ndarray,
    atac_embedding: np.ndarray,
    quotient_rna: np.ndarray,
    quotient_atac: np.ndarray,
    centroid_residual: np.ndarray,
    markers: dict[int, list[str]],
    stability: pd.DataFrame,
    membership_threshold: float,
) -> pd.DataFrame:
    assigned = np.argmax(membership, axis=1)
    max_membership = np.max(membership, axis=1)
    quotient_residual = np.abs(quotient_rna - quotient_atac)
    stability_lookup = stability.set_index(["state_i", "state_j"])
    rows = []

    for i, j in combinations(range(membership.shape[1]), 2):
        mask = np.isin(assigned, [i, j])
        pair_labels = labels[mask]
        rna_sil = safe_pair_silhouette(rna_embedding, assigned, i, j)
        atac_sil = safe_pair_silhouette(atac_embedding, assigned, i, j)
        genes_i = markers.get(i, [])
        genes_j = markers.get(j, [])
        set_i = set(genes_i[:20])
        set_j = set(genes_j[:20])
        marker_jaccard = len(set_i & set_j) / max(len(set_i | set_j), 1)
        stable = stability_lookup.loc[(i, j)]

        rows.append(
            {
                "state_i": i,
                "state_j": j,
                "state_pair": f"S{i}-S{j}",
                "n_pair_assigned_cells": int(mask.sum()),
                "low_membership_fraction": float(
                    np.mean(max_membership[mask] < membership_threshold)
                ),
                "annotation_entropy_normalized": normalized_entropy(pair_labels),
                "rna_silhouette": rna_sil,
                "atac_silhouette": atac_sil,
                "rna_atac_silhouette_discrepancy": abs(rna_sil - atac_sil),
                "marker_list_dissimilarity": 1.0 - marker_jaccard,
                "q_rna": float(quotient_rna[i, j]),
                "q_atac": float(quotient_atac[i, j]),
                "quotient_residual": float(quotient_residual[i, j]),
                "centroid_residual": float(centroid_residual[i, j]),
                "quotient_mean_across_seeds": float(
                    stable["quotient_mean_across_seeds"]
                ),
                "quotient_sd_across_seeds": float(
                    stable["quotient_sd_across_seeds"]
                ),
                "quotient_cv_across_seeds": float(
                    stable["quotient_cv_across_seeds"]
                ),
                "quotient_mean_rank": float(stable["quotient_mean_rank"]),
                "quotient_top5_frequency": float(
                    stable["quotient_top5_frequency"]
                ),
                "state_i_composition": state_composition(labels, assigned, i),
                "state_j_composition": state_composition(labels, assigned, j),
                "state_i_top_markers": ";".join(genes_i[:10]),
                "state_j_top_markers": ";".join(genes_j[:10]),
                "state_i_marker_programs": format_program_hits(
                    marker_program_hits(genes_i)
                ),
                "state_j_marker_programs": format_program_hits(
                    marker_program_hits(genes_j)
                ),
            }
        )
    return pd.DataFrame(rows)


def add_selection_groups(pair_df: pd.DataFrame, top_n: int) -> pd.DataFrame:
    quotient_pairs = set(
        pair_df.nlargest(top_n, "quotient_residual")["state_pair"].tolist()
    )
    centroid_pairs = set(
        pair_df.nlargest(top_n, "centroid_residual")["state_pair"].tolist()
    )
    rows = []
    for method, selected in (
        ("Quotient residual", quotient_pairs),
        ("Centroid baseline", centroid_pairs),
    ):
        subset = pair_df[pair_df["state_pair"].isin(selected)].copy()
        subset.insert(0, "selection_method", method)
        rows.append(subset)
    return pd.concat(rows, ignore_index=True)


def summarize_groups(selected_df: pd.DataFrame) -> pd.DataFrame:
    metrics = [
        "low_membership_fraction",
        "annotation_entropy_normalized",
        "rna_atac_silhouette_discrepancy",
        "marker_list_dissimilarity",
        "quotient_top5_frequency",
        "quotient_cv_across_seeds",
    ]
    rows = []
    for method, sub in selected_df.groupby("selection_method", sort=False):
        row = {"selection_method": method, "n_pairs": len(sub)}
        for metric in metrics:
            row[f"{metric}_mean"] = float(sub[metric].mean())
            row[f"{metric}_median"] = float(sub[metric].median())
        rows.append(row)
    return pd.DataFrame(rows)


def plot_comparison(selected_df: pd.DataFrame, out_dir: Path) -> None:
    metrics = [
        ("low_membership_fraction", "Low-membership fraction"),
        ("annotation_entropy_normalized", "Annotation entropy"),
        ("rna_atac_silhouette_discrepancy", "RNA-ATAC silhouette difference"),
        ("marker_list_dissimilarity", "Marker-list dissimilarity"),
        ("quotient_top5_frequency", "Top-5 frequency across seeds"),
    ]
    palette = {
        "Quotient residual": "#3C78A8",
        "Centroid baseline": "#9A9A9A",
    }
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans"],
            "font.size": 7,
            "axes.linewidth": 0.7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )
    fig, axes = plt.subplots(1, len(metrics), figsize=(11.2, 2.55))
    rng = np.random.default_rng(17)
    methods = ["Quotient residual", "Centroid baseline"]

    for ax, (metric, title) in zip(axes, metrics):
        for x, method in enumerate(methods):
            values = selected_df.loc[
                selected_df["selection_method"] == method, metric
            ].to_numpy(dtype=float)
            jitter = rng.normal(0, 0.035, size=len(values))
            ax.scatter(
                np.full(len(values), x) + jitter,
                values,
                s=24,
                color=palette[method],
                alpha=0.9,
                edgecolor="white",
                linewidth=0.35,
                zorder=3,
            )
            median = np.nanmedian(values)
            ax.plot([x - 0.18, x + 0.18], [median, median], color="black", lw=1.2)
        ax.set_xticks([0, 1], ["Quotient", "Centroid"], rotation=25, ha="right")
        ax.set_title(title, fontsize=7.5)
        ax.grid(axis="y", color="#E3E3E3", linewidth=0.55)

    axes[0].set_ylabel("Pair-level metric")
    fig.tight_layout(w_pad=1.35)
    for suffix, kwargs in (
        ("png", {"dpi": 500}),
        ("tiff", {"dpi": 600}),
        ("pdf", {}),
        ("svg", {}),
    ):
        fig.savefig(
            out_dir / f"quotient_vs_centroid_pair_utility.{suffix}",
            bbox_inches="tight",
            **kwargs,
        )
    plt.close(fig)


def plot_top3(pair_df: pd.DataFrame, out_dir: Path) -> None:
    top3 = pair_df.nlargest(3, "quotient_residual").copy()
    x = np.arange(len(top3))
    width = 0.34
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans"],
            "font.size": 7,
            "axes.linewidth": 0.7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 2.7))
    ax = axes[0]
    ax.bar(x - width / 2, top3["q_rna"], width, label="RNA", color="#4C78A8")
    ax.bar(x + width / 2, top3["q_atac"], width, label="ATAC", color="#F28E2B")
    ax.set_xticks(x, top3["state_pair"])
    ax.set_ylabel("Normalized quotient distance")
    ax.set_title("Top quotient-residual pairs")
    ax.legend()
    ax.grid(axis="y", color="#E3E3E3", linewidth=0.55)

    ax = axes[1]
    ax.bar(
        x,
        top3["quotient_mean_across_seeds"],
        yerr=top3["quotient_sd_across_seeds"],
        color="#59A14F",
        capsize=2.5,
        error_kw={"linewidth": 0.8},
    )
    ax.scatter(x, top3["quotient_residual"], color="#D55E00", s=22, zorder=3)
    ax.set_xticks(x, top3["state_pair"])
    ax.set_ylabel("Quotient residual")
    ax.set_title("Residual stability across seeds")
    ax.grid(axis="y", color="#E3E3E3", linewidth=0.55)

    for label, ax in zip(("a", "b"), axes):
        ax.text(-0.14, 1.07, label, transform=ax.transAxes, fontweight="bold", fontsize=9)
    fig.tight_layout(w_pad=2.0)
    for suffix, kwargs in (
        ("png", {"dpi": 500}),
        ("tiff", {"dpi": 600}),
        ("pdf", {}),
        ("svg", {}),
    ):
        fig.savefig(
            out_dir / f"top3_quotient_residual_pairs.{suffix}",
            bbox_inches="tight",
            **kwargs,
        )
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed-dir", default="outputs/fqalign_10seeds/seed8")
    parser.add_argument(
        "--rna-embedding", default="outputs/baselines/RNA_PCA_embedding.npy"
    )
    parser.add_argument(
        "--atac-embedding", default="outputs/baselines/ATAC_LSI_embedding.npy"
    )
    parser.add_argument(
        "--stability-table",
        default="outputs/residual_validation_seed8_reference/residual_pair_stability.csv",
    )
    parser.add_argument(
        "--marker-table",
        default="outputs/fqalign_10seeds/seed8/top_markers_per_state.csv",
    )
    parser.add_argument("--top-n", type=int, default=5)
    parser.add_argument("--membership-threshold", type=float, default=0.6)
    parser.add_argument(
        "--out-dir", default="outputs/residual_pair_utility_validation"
    )
    args = parser.parse_args()

    seed_dir = Path(args.seed_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    membership = np.load(seed_dir / "fqalign_membership.npy")
    q_rna = np.load(seed_dir / "quotient_distance_rna.npy")
    q_atac = np.load(seed_dir / "quotient_distance_atac.npy")
    rna_embedding = np.load(args.rna_embedding)
    atac_embedding = np.load(args.atac_embedding)
    cell_df = pd.read_csv(seed_dir / "cell_modality_reliability.csv")
    labels = cell_df["celltype"]
    markers = parse_markers(Path(args.marker_table))
    stability = pd.read_csv(args.stability_table)

    if not (
        len(cell_df)
        == membership.shape[0]
        == rna_embedding.shape[0]
        == atac_embedding.shape[0]
    ):
        raise ValueError("Cell counts do not match across saved inputs.")

    centroid_rna = fuzzy_centroid_distances(rna_embedding, membership)
    centroid_atac = fuzzy_centroid_distances(atac_embedding, membership)
    centroid_residual = np.abs(centroid_rna - centroid_atac)

    pair_df = build_pair_metrics(
        membership=membership,
        labels=labels,
        rna_embedding=rna_embedding,
        atac_embedding=atac_embedding,
        quotient_rna=q_rna,
        quotient_atac=q_atac,
        centroid_residual=centroid_residual,
        markers=markers,
        stability=stability,
        membership_threshold=args.membership_threshold,
    )
    pair_df["quotient_rank"] = pair_df["quotient_residual"].rank(
        method="min", ascending=False
    )
    pair_df["centroid_rank"] = pair_df["centroid_residual"].rank(
        method="min", ascending=False
    )
    pair_df.to_csv(out_dir / "all_state_pair_utility_metrics.csv", index=False)

    selected_df = add_selection_groups(pair_df, args.top_n)
    selected_df.to_csv(
        out_dir / "top_quotient_vs_centroid_pairs.csv", index=False
    )
    summary_df = summarize_groups(selected_df)
    summary_df.to_csv(
        out_dir / "quotient_vs_centroid_utility_summary.csv", index=False
    )

    top3 = pair_df.nlargest(3, "quotient_residual").copy()
    top3.to_csv(out_dir / "top3_quotient_residual_pair_cases.csv", index=False)

    quotient_set = set(
        pair_df.nlargest(args.top_n, "quotient_residual")["state_pair"]
    )
    centroid_set = set(
        pair_df.nlargest(args.top_n, "centroid_residual")["state_pair"]
    )
    overlap = sorted(quotient_set.intersection(centroid_set))
    metadata = {
        "top_n": args.top_n,
        "membership_threshold": args.membership_threshold,
        "top_quotient_pairs": sorted(quotient_set),
        "top_centroid_pairs": sorted(centroid_set),
        "overlap_pairs": overlap,
        "overlap_count": len(overlap),
        "interpretation_note": (
            "Marker-program names report overlap with predefined gene sets; "
            "they are descriptive and are not cell-type assignments."
        ),
    }
    (out_dir / "analysis_metadata.json").write_text(
        json.dumps(metadata, indent=2), encoding="utf-8"
    )

    plot_comparison(selected_df, out_dir)
    plot_top3(pair_df, out_dir)

    print(summary_df.to_string(index=False))
    print(json.dumps(metadata, indent=2))
    print(f"Wrote results to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
