import os
import glob
import re
import pandas as pd


OUT = "outputs/paper_tables"
os.makedirs(OUT, exist_ok=True)


def read_csv_safe(path):
    try:
        return pd.read_csv(path)
    except Exception as e:
        print("[SKIP]", path, e)
        return None


def infer_seed_from_path(path):
    m = re.search(r"seed(\d+)", path)
    if m:
        return int(m.group(1))
    return None


def normalize_method_name(path, default):
    low = path.lower()

    if "fqalign" in low:
        return "FQ-Align"
    if "scglue" in low:
        return "SCGLUE"
    if "multivi" in low:
        return "MultiVI"
    if "cobolt" in low:
        return "Cobolt"
    if "mofa" in low:
        return "MOFA+"

    return default


rows = []

# =====================================================
# 1. FQ-Align train seeds: metrics_best.csv
# =====================================================

for path in glob.glob("outputs/fqalign_10seeds/seed*/metrics_best.csv"):
    df = read_csv_safe(path)
    if df is None or df.empty:
        continue

    seed = infer_seed_from_path(path)

    row = df.iloc[0].to_dict()
    rows.append({
        "Method": "FQ-Align",
        "TrainSeed": seed,
        "EvalSeed": row.get("kmeans_seed", None),
        "ARI": row.get("ARI", None),
        "NMI": row.get("NMI", None),
        "AMI": row.get("AMI", None),
        "Sil_pred": row.get("Sil_pred", None),
        "Sil_label": row.get("Sil_label", None),
        "Source": path,
        "Type": "train_seed_best",
    })


# =====================================================
# 2. Baselines: *_metrics_by_seed.csv
# =====================================================

patterns = [
    "outputs/scglue/*metrics_by_seed.csv",
    "outputs/multivi/*metrics_by_seed.csv",
    "outputs/cobolt/*metrics_by_seed.csv",
    "outputs/mofa/*metrics_by_seed.csv",
    "outputs/**/SCGLUE*metrics_by_seed.csv",
    "outputs/**/MultiVI*metrics_by_seed.csv",
    "outputs/**/Cobolt*metrics_by_seed.csv",
    "outputs/**/MOFA*metrics_by_seed.csv",
]

seen = set()

for pat in patterns:
    for path in glob.glob(pat, recursive=True):
        path = os.path.normpath(path)
        if path in seen:
            continue
        seen.add(path)

        df = read_csv_safe(path)
        if df is None or df.empty:
            continue

        method = normalize_method_name(path, default=os.path.basename(path).split("_")[0])

        for i, row in df.iterrows():
            rows.append({
                "Method": method,
                "TrainSeed": None,
                "EvalSeed": row.get("seed", row.get("kmeans_seed", i)),
                "ARI": row.get("ARI", None),
                "NMI": row.get("NMI", None),
                "AMI": row.get("AMI", None),
                "Sil_pred": row.get("Sil_pred", None),
                "Sil_label": row.get("Sil_label", None),
                "Source": path,
                "Type": "eval_seed",
            })


# =====================================================
# 3. If no by_seed exists, collect *_metrics_summary.csv
# =====================================================

summary_rows = []

for path in glob.glob("outputs/**/*metrics_summary.csv", recursive=True):
    df = read_csv_safe(path)
    if df is None or df.empty:
        continue

    method = normalize_method_name(path, default=os.path.basename(path).split("_")[0])

    row = df.iloc[0].to_dict()

    summary_rows.append({
        "Method": method,
        "ARI_mean": row.get("ARI_mean", row.get("ARI", None)),
        "ARI_std": row.get("ARI_std", None),
        "ARI_best": row.get("ARI_best", row.get("ARI", None)),
        "NMI_mean": row.get("NMI_mean", row.get("NMI", None)),
        "AMI_mean": row.get("AMI_mean", row.get("AMI", None)),
        "Sil_pred_mean": row.get("Sil_pred_mean", row.get("Sil_pred", None)),
        "Source": path,
    })


all_df = pd.DataFrame(rows)

# remove empty ARI rows
if not all_df.empty:
    all_df = all_df.dropna(subset=["ARI"])
    all_df.to_csv(os.path.join(OUT, "all_seed_metrics_long.csv"), index=False)

    summary = (
        all_df.groupby("Method")
        .agg(
            n=("ARI", "size"),
            ARI_mean=("ARI", "mean"),
            ARI_std=("ARI", "std"),
            ARI_best=("ARI", "max"),
            NMI_mean=("NMI", "mean"),
            NMI_std=("NMI", "std"),
            NMI_best=("NMI", "max"),
            Sil_pred_mean=("Sil_pred", "mean"),
            Sil_pred_std=("Sil_pred", "std"),
        )
        .reset_index()
        .sort_values("ARI_mean", ascending=False)
    )

    summary.to_csv(os.path.join(OUT, "all_seed_metrics_summary.csv"), index=False)

    print("\n=== Long table ===")
    print(all_df.head().to_string(index=False))

    print("\n=== Summary ===")
    print(summary.to_string(index=False))
else:
    print("[WARN] No per-seed metrics found.")

if summary_rows:
    summary_df = pd.DataFrame(summary_rows)
    summary_df.to_csv(os.path.join(OUT, "collected_metrics_summary_files.csv"), index=False)
    print("\n=== Collected summary files ===")
    print(summary_df.to_string(index=False))

print("\nSaved to:", OUT)