import argparse
import os

import numpy as np
import pandas as pd

from multiome_common import labels_and_mask, load_paired_h5ad, save_embedding_result


def is_metrics_by_seed_file(filename):
    name = filename.lower()
    return (
        name.endswith(".csv")
        and "by_seed" in name
        and "metrics" in name
    )


def infer_method_from_path(path):
    base = os.path.basename(path)

    parent = os.path.basename(os.path.dirname(path))
    grand = os.path.basename(os.path.dirname(os.path.dirname(path)))

    if base == "metrics_learned_z_by_seed.csv":
        return f"{grand}/{parent}/learned_z"

    if base == "metrics_by_seed.csv":
        return f"{grand}/{parent}/final"

    if base.endswith("_metrics_by_seed.csv"):
        method = base.replace("_metrics_by_seed.csv", "")
        return method

    return f"{grand}/{parent}/{base.replace('.csv', '')}"


def read_method_csv(path):
    df = pd.read_csv(path)

    required = {"ARI", "NMI"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"{path} missing required columns: {missing}")

    df["method"] = infer_method_from_path(path)
    df["source_path"] = path
    return df


def resolve_path(path):
    return os.path.abspath(os.path.expanduser(path))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--rna", default="rna_clean.h5ad")
    parser.add_argument("--atac", default="atac_clean.h5ad")
    parser.add_argument("--label-key", default="celltype")
    parser.add_argument("--out-dir", default="outputs/unified_eval")
    parser.add_argument("--eval-seeds", type=int, default=10)

    parser.add_argument(
        "--embedding",
        action="append",
        default=[],
        help="Evaluate NAME=PATH .npy embedding against the clean labels.",
    )
    parser.add_argument(
        "--metrics-csv",
        action="append",
        default=[],
        help="Collect an existing metrics by-seed csv.",
    )
    parser.add_argument(
        "--scan",
        action="append",
        default=[],
        help="Recursively collect metrics/by_seed csv files under this directory.",
    )

    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)

    rna, atac = load_paired_h5ad(args.data_dir, args.rna, args.atac, args.label_key)
    labels, mask = labels_and_mask(rna, args.label_key)

    all_by_seed = []
    all_summary = []

    for spec in args.embedding:
        if "=" not in spec:
            raise ValueError("--embedding must be NAME=PATH")

        method, path = spec.split("=", 1)
        path = resolve_path(path)

        emb = np.load(path)
        if emb.shape[0] != rna.n_obs:
            raise ValueError(f"{method} has {emb.shape[0]} cells, expected {rna.n_obs}.")

        _, by_seed, summary = save_embedding_result(
            args.out_dir,
            method,
            emb,
            labels,
            mask,
            seeds=args.eval_seeds,
        )
        all_by_seed.append(by_seed)
        all_summary.append(summary)

    metrics_csv = []

    for path in args.metrics_csv:
        metrics_csv.append(resolve_path(path))

    for root in args.scan:
        root = resolve_path(root)

        if not os.path.exists(root):
            print(f"[WARN] scan path does not exist: {root}")
            continue

        for dirpath, _, filenames in os.walk(root):
            for filename in filenames:
                if is_metrics_by_seed_file(filename):
                    metrics_csv.append(os.path.join(dirpath, filename))

    seen = set()
    for path in metrics_csv:
        path = os.path.normpath(path)

        if path in seen:
            continue
        seen.add(path)

        try:
            df = read_method_csv(path)
        except Exception as e:
            print(f"[SKIP] {path}: {e}")
            continue

        all_by_seed.append(df)

    if all_by_seed:
        by_seed = pd.concat(all_by_seed, ignore_index=True)

        by_seed.to_csv(
            os.path.join(args.out_dir, "all_metrics_by_seed.csv"),
            index=False,
        )

        agg_dict = {
            "n": ("ARI", "size"),
            "ARI_mean": ("ARI", "mean"),
            "ARI_std": ("ARI", "std"),
            "ARI_best": ("ARI", "max"),
            "NMI_mean": ("NMI", "mean"),
            "NMI_std": ("NMI", "std"),
        }

        if "AMI" in by_seed.columns:
            agg_dict["AMI_mean"] = ("AMI", "mean")

        if "Sil_pred" in by_seed.columns:
            agg_dict["Sil_pred_mean"] = ("Sil_pred", "mean")

        if "Sil_label" in by_seed.columns:
            agg_dict["Sil_label_mean"] = ("Sil_label", "mean")

        summary = by_seed.groupby("method", as_index=False).agg(**agg_dict)
        summary = summary.sort_values("ARI_mean", ascending=False)

        summary.to_csv(
            os.path.join(args.out_dir, "all_metrics_summary.csv"),
            index=False,
        )

        print(summary.to_string(index=False))
        print("\nSaved:")
        print(os.path.join(args.out_dir, "all_metrics_by_seed.csv"))
        print(os.path.join(args.out_dir, "all_metrics_summary.csv"))

    elif all_summary:
        pd.concat(all_summary, ignore_index=True).to_csv(
            os.path.join(args.out_dir, "all_metrics_summary.csv"),
            index=False,
        )
    else:
        print("No embeddings or metrics CSV files were provided.")


if __name__ == "__main__":
    main()