import argparse
import os

import numpy as np
import scipy.sparse as sp

from multiome_common import (
    labels_and_mask,
    load_paired_h5ad,
    save_embedding_result,
    select_atac_features,
    select_top_columns_by_sum,
    subset_atac_with_gene_peak,
    validate_gene_peak,
)


def as_csr_counts(x):
    if not sp.issparse(x):
        x = sp.csr_matrix(x)
    x = x.astype("float32").tocsr()
    x.data = np.nan_to_num(x.data, nan=0.0, posinf=0.0, neginf=0.0)
    x.data[x.data < 0] = 0
    return x


def extract_latent(model, dataset):
    candidates = [
        lambda: model.get_all_latent(),
        lambda: model.get_latent(),
        lambda: model.get_latent_representation(),
        lambda: model.get_embedding(),
        lambda: model.calc_all_latent(),
    ]
    for fn in candidates:
        try:
            z = fn()
            if isinstance(z, tuple):
                z = z[0]
            if isinstance(z, dict):
                for value in z.values():
                    arr = np.asarray(value)
                    if arr.ndim == 2:
                        return arr
            arr = np.asarray(z)
            if arr.ndim == 2:
                return arr
        except Exception:
            pass
    raise RuntimeError(
        "Could not extract Cobolt latent embedding. Check the installed Cobolt API version."
    )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--rna", default="rna_clean.h5ad")
    parser.add_argument("--atac", default="atac_clean.h5ad")
    parser.add_argument("--gene-peak", default="gene_peak.npz")
    parser.add_argument("--label-key", default="celltype")
    parser.add_argument("--out-dir", default="outputs/cobolt")
    parser.add_argument("--n-rna-features", type=int, default=3000)
    parser.add_argument("--n-atac-peaks", type=int, default=50000)
    parser.add_argument("--n-latent", type=int, default=32)
    parser.add_argument("--epochs", type=int, default=100)
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--eval-seeds", type=int, default=10)
    args = parser.parse_args()

    try:
        from cobolt.model import Cobolt
        from cobolt.utils import MultiomicDataset, SingleData
    except Exception as exc:
        raise ImportError(
            "Cobolt is not installed or its API is unavailable. Use the cobolt environment file, "
            "then rerun this script."
        ) from exc

    os.makedirs(args.out_dir, exist_ok=True)
    rna, atac = load_paired_h5ad(args.data_dir, args.rna, args.atac, args.label_key)
    gene_peak = validate_gene_peak(os.path.join(args.data_dir, args.gene_peak), rna, atac, require_match=True)

    gene_idx = select_top_columns_by_sum(rna, args.n_rna_features)
    rna = rna[:, gene_idx].copy()
    gene_peak = gene_peak[gene_idx, :].tocsr()

    peak_idx = select_atac_features(atac, args.n_atac_peaks, gene_peak=gene_peak, mode="linked_plus_top")
    atac, gene_peak = subset_atac_with_gene_peak(atac, gene_peak, peak_idx)
    print(f"Cobolt feature subset RNA={rna.shape}, ATAC={atac.shape}, linked_edges={gene_peak.nnz}")

    rna_x = as_csr_counts(rna.X)
    atac_x = as_csr_counts(atac.X)
    cells = rna.obs_names.astype(str).values

    try:
        rna_data = SingleData(
            "GeneExpr",
            "multiome",
            rna.var_names.astype(str).values,
            rna_x,
            cells,
        )
        atac_data = SingleData(
            "ChromAccess",
            "multiome",
            atac.var_names.astype(str).values,
            atac_x,
            cells,
        )
    except TypeError:
        rna_data = SingleData(
            data_type="GeneExpr",
            dataset_name="multiome",
            feature_name=rna.var_names.astype(str).values,
            count_matrix=rna_x,
            barcode=cells,
        )
        atac_data = SingleData(
            data_type="ChromAccess",
            dataset_name="multiome",
            feature_name=atac.var_names.astype(str).values,
            count_matrix=atac_x,
            barcode=cells,
        )

    try:
        dataset = MultiomicDataset.from_singledata(rna_data, atac_data)
    except Exception:
        dataset = MultiomicDataset([rna_data, atac_data])

    try:
        model = Cobolt(
            dataset=dataset,
            lr=args.lr,
            n_latent=args.n_latent,
        )
    except TypeError:
        model = Cobolt(dataset, lr=args.lr, n_latent=args.n_latent)

    try:
        model.train(num_epochs=args.epochs, batch_size=args.batch_size)
    except TypeError:
        try:
            model.train(num_epochs=args.epochs)
        except TypeError:
            model.train(args.epochs)

    latent = extract_latent(model, dataset)
    if latent.shape[0] != rna.n_obs:
        raise ValueError(f"Cobolt latent has {latent.shape[0]} cells, expected {rna.n_obs}.")

    labels, mask = labels_and_mask(rna, args.label_key)
    best, _, _ = save_embedding_result(
        args.out_dir,
        "Cobolt",
        latent,
        labels,
        mask,
        seeds=args.eval_seeds,
        extra={
            "n_rna_features": args.n_rna_features,
            "n_atac_peaks": args.n_atac_peaks,
            "n_latent": args.n_latent,
        },
    )
    print(f"Cobolt best_ARI={best['ARI']:.4f} NMI={best['NMI']:.4f} Sil_pred={best['Sil_pred']:.4f}")


if __name__ == "__main__":
    main()
