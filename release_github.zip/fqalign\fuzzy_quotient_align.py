import argparse
import json
import os
import warnings

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

from multiome_common import (
    atac_lsi,
    labels_and_mask,
    load_paired_h5ad,
    rna_pca,
    save_embedding_result,
    validate_gene_peak,
)

warnings.filterwarnings("ignore")


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.deterministic = True


def load_paired_representations(data_dir, rna_file, atac_file, label_key, n_pcs, gene_peak=None):
    rna, atac = load_paired_h5ad(data_dir, rna_file, atac_file, label_key)
    if gene_peak is not None:
        validate_gene_peak(os.path.join(data_dir, gene_peak), rna, atac, require_match=True)
        print(f"gene_peak matched: ({rna.n_vars}, {atac.n_vars})")

    x_rna = rna_pca(rna, n_pcs=n_pcs)
    x_atac = atac_lsi(atac, n_pcs=n_pcs)

    if x_rna.shape[1] != x_atac.shape[1]:
        min_dim = min(x_rna.shape[1], x_atac.shape[1])
        x_rna = x_rna[:, :min_dim]
        x_atac = x_atac[:, :min_dim]

    print(f"RNA dim: {x_rna.shape[1]}, ATAC dim: {x_atac.shape[1]}")
    labels, labeled_mask = labels_and_mask(rna, label_key)
    return rna, atac, x_rna, x_atac, labels, labeled_mask


class Encoder(nn.Module):
    def __init__(self, in_dim, z_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_dim, 128),
            nn.BatchNorm1d(128),
            nn.ReLU(),
            nn.Dropout(0.05),
            nn.Linear(128, z_dim),
        )

    def forward(self, x):
        return F.normalize(self.net(x), dim=1)


class ReliabilityGate(nn.Module):
    def __init__(self, z_dim):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(4 * z_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 2),
        )

    def forward(self, z_rna, z_atac):
        h = torch.cat([z_rna, z_atac, torch.abs(z_rna - z_atac), z_rna * z_atac], dim=1)
        return F.softmax(self.net(h), dim=1)


class FuzzyQuotientAlign(nn.Module):
    def __init__(self, in_dim, z_dim, n_states):
        super().__init__()
        self.rna_encoder = Encoder(in_dim, z_dim)
        self.atac_encoder = Encoder(in_dim, z_dim)
        self.gate = ReliabilityGate(z_dim)
        self.prototypes = nn.Parameter(torch.randn(n_states, z_dim))

    def fuzzy_membership(self, z, temperature):
        c = F.normalize(self.prototypes, dim=1)
        dist2 = torch.cdist(z, c).pow(2)
        return F.softmax(-dist2 / temperature, dim=1), dist2

    def forward(self, x_rna, x_atac, temperature):
        z_rna = self.rna_encoder(x_rna)
        z_atac = self.atac_encoder(x_atac)
        weights = self.gate(z_rna, z_atac)
        z = F.normalize(weights[:, 0:1] * z_rna + weights[:, 1:2] * z_atac, dim=1)
        u, dist2 = self.fuzzy_membership(z, temperature)
        return z_rna, z_atac, z, weights, u, dist2


def info_nce(z_rna, z_atac, tau):
    logits = z_rna @ z_atac.T / tau
    labels = torch.arange(z_rna.size(0), device=z_rna.device)
    return 0.5 * (F.cross_entropy(logits, labels) + F.cross_entropy(logits.T, labels))


def quotient_distance_loss(u, x_rna, x_atac, eps=1e-8):
    d_rna = torch.cdist(x_rna, x_rna)
    d_atac = torch.cdist(x_atac, x_atac)
    d_rna = d_rna / (d_rna.mean().detach() + eps)
    d_atac = d_atac / (d_atac.mean().detach() + eps)

    mass = u.sum(dim=0).clamp_min(eps)
    denom = mass[:, None] * mass[None, :]
    q_rna = (u.T @ d_rna @ u) / denom
    q_atac = (u.T @ d_atac @ u) / denom
    return F.mse_loss(q_rna, q_atac), q_rna, q_atac


def fuzzy_compactness(u, dist2, m):
    return ((u.clamp_min(1e-8).pow(m)) * dist2).sum(dim=1).mean()


def reliability_loss(weights, u, z_rna, z_atac, prototypes, temperature, prior_rna):
    c = F.normalize(prototypes, dim=1)
    d_rna = torch.cdist(z_rna, c).pow(2)
    d_atac = torch.cdist(z_atac, c).pow(2)
    e_rna = (u.detach() * d_rna).sum(dim=1)
    e_atac = (u.detach() * d_atac).sum(dim=1)

    prior = torch.tensor([prior_rna, 1.0 - prior_rna], device=weights.device).clamp_min(1e-6)
    log_prior = torch.log(prior)

    score = -torch.stack([e_rna, e_atac], dim=1) / temperature + log_prior
    target = F.softmax(score, dim=1).detach()
    return F.kl_div((weights + 1e-8).log(), target, reduction="batchmean")


def balance_loss(weights, prior_rna):
    mean_w = weights.mean(dim=0)
    target = torch.tensor([prior_rna, 1.0 - prior_rna], device=weights.device)
    return F.mse_loss(mean_w, target)


def pairwise_structure_loss(z, x, eps=1e-8):
    dz = torch.cdist(z, z)
    dx = torch.cdist(x, x)
    dz = dz / (dz.mean().detach() + eps)
    dx = dx / (dx.mean().detach() + eps)
    return F.mse_loss(dz, dx.detach())


def state_balance_loss(u, eps=1e-8):
    p = u.mean(dim=0).clamp_min(eps)
    uniform = torch.full_like(p, 1.0 / p.numel())
    return F.kl_div(p.log(), uniform, reduction="batchmean")


def prototype_orthogonality_loss(prototypes):
    c = F.normalize(prototypes, dim=1)
    sim = c @ c.T
    eye = torch.eye(sim.size(0), device=sim.device)
    return ((sim - eye) ** 2).mean()


def initialize_gate_prior(model, prior_rna):
    final = model.gate.net[-1]
    with torch.no_grad():
        final.weight.zero_()
        prior = torch.tensor([prior_rna, 1.0 - prior_rna], device=final.bias.device).clamp_min(1e-6)
        final.bias.copy_(torch.log(prior))


def initialize_prototypes_from_kmeans(model, x_rna, x_atac, args):
    model.eval()
    with torch.no_grad():
        _, _, z, _, _, _ = model(x_rna, x_atac, args.temperature)
    km = KMeans(n_clusters=args.states, n_init=50, random_state=args.seed).fit(
        z.detach().cpu().numpy()
    )
    centers = torch.tensor(km.cluster_centers_, device=x_rna.device, dtype=torch.float32)
    centers = F.normalize(centers, dim=1)
    with torch.no_grad():
        model.prototypes.copy_(centers)
    model.train()


def standardize_np(x):
    return StandardScaler().fit_transform(x).astype("float32")


def maybe_standardize_block(x, standardize):
    if standardize == "blocks":
        return standardize_np(x)
    return x.astype("float32")


def build_final_embedding(
    mode,
    x_rna,
    x_atac,
    z,
    u,
    weights,
    atac_weight,
    z_weight,
    u_weight,
    standardize,
):
    if standardize not in {"none", "all", "blocks"}:
        raise ValueError(f"Unknown final standardization mode: {standardize}")

    xr = maybe_standardize_block(x_rna, standardize)
    xa = maybe_standardize_block(x_atac, standardize)
    zz = maybe_standardize_block(z, standardize)
    uu = maybe_standardize_block(u, standardize)

    if mode == "learned":
        emb = zz
    elif mode == "raw_weighted":
        emb = np.hstack([xr, atac_weight * xa])
    elif mode == "cell_weighted":
        emb = np.hstack([weights[:, 0:1] * xr, weights[:, 1:2] * xa])
    elif mode == "hybrid":
        emb = np.hstack([xr, atac_weight * xa, z_weight * zz, u_weight * uu])
    elif mode == "cell_hybrid":
        emb = np.hstack(
            [
                weights[:, 0:1] * xr,
                weights[:, 1:2] * xa,
                z_weight * zz,
                u_weight * uu,
            ]
        )
    else:
        raise ValueError(f"Unknown final embedding mode: {mode}")

    if standardize == "all":
        emb = standardize_np(emb)

    return emb.astype("float32")


def evaluate_final_candidates(
    x_rna,
    x_atac,
    z,
    u,
    weights,
    labels,
    mask,
    eval_seeds,
    standardize,
    out_dir,
):
    from multiome_common import evaluate_embedding

    candidates = {
        "learned": build_final_embedding(
            "learned", x_rna, x_atac, z, u, weights, 0.0, 1.0, 0.0, standardize
        ),
        "cell_weighted": build_final_embedding(
            "cell_weighted", x_rna, x_atac, z, u, weights, 0.0, 1.0, 0.0, standardize
        ),
    }

    for atac_weight in [0.05, 0.1, 0.2, 0.5, 0.7]:
        candidates[f"raw_weighted_atac_{atac_weight:g}"] = build_final_embedding(
            "raw_weighted", x_rna, x_atac, z, u, weights, atac_weight, 0.0, 0.0, standardize
        )

    for atac_weight in [0.05, 0.1, 0.2, 0.5]:
        for z_weight in [0.5, 1.0, 2.0, 4.0]:
            for u_weight in [0.0, 0.25, 0.5, 1.0]:
                name = f"hybrid_a{atac_weight:g}_z{z_weight:g}_u{u_weight:g}"
                candidates[name] = build_final_embedding(
                    "hybrid",
                    x_rna,
                    x_atac,
                    z,
                    u,
                    weights,
                    atac_weight,
                    z_weight,
                    u_weight,
                    standardize,
                )

    for z_weight in [0.5, 1.0, 2.0, 4.0]:
        for u_weight in [0.0, 0.25, 0.5, 1.0]:
            name = f"cell_hybrid_z{z_weight:g}_u{u_weight:g}"
            candidates[name] = build_final_embedding(
                "cell_hybrid",
                x_rna,
                x_atac,
                z,
                u,
                weights,
                0.0,
                z_weight,
                u_weight,
                standardize,
            )

    rows = []
    by_seed_frames = []
    best = None
    best_embedding = None

    for name, emb in candidates.items():
        local_best, by_seed, _ = evaluate_embedding(
            emb, labels, mask, seeds=eval_seeds, method=name
        )
        rows.append(local_best)
        by_seed_frames.append(by_seed)
        if best is None or local_best["ARI"] > best["ARI"]:
            best = local_best
            best_embedding = emb

    ranked = pd.DataFrame(rows).sort_values("ARI", ascending=False)
    ranked.to_csv(os.path.join(out_dir, "final_embedding_candidates_ranked.csv"), index=False)

    pd.concat(by_seed_frames, ignore_index=True).to_csv(
        os.path.join(out_dir, "final_embedding_candidates_by_seed.csv"), index=False
    )

    return best, best_embedding, ranked


def state_summary(obs_names, labels, weights, membership):
    state = membership.argmax(axis=1)
    df = pd.DataFrame(
        {
            "cell": obs_names,
            "celltype": labels,
            "state": state,
            "rna_weight": weights[:, 0],
            "atac_weight": weights[:, 1],
            "max_membership": membership.max(axis=1),
        }
    )

    summary = (
        df.groupby("state")
        .agg(
            n_cells=("cell", "count"),
            mean_rna_weight=("rna_weight", "mean"),
            mean_atac_weight=("atac_weight", "mean"),
            mean_max_membership=("max_membership", "mean"),
        )
        .reset_index()
    )

    celltype_summary = (
        df[df["celltype"] != "nan"]
        .groupby("celltype")
        .agg(
            n_cells=("cell", "count"),
            mean_rna_weight=("rna_weight", "mean"),
            mean_atac_weight=("atac_weight", "mean"),
            mean_max_membership=("max_membership", "mean"),
        )
        .reset_index()
    )

    state_celltype = pd.crosstab(df["state"], df["celltype"], normalize="index").reset_index()

    return df, summary, celltype_summary, state_celltype


def compute_losses(model, br, ba, args, quotient_weight, scales=None):
    scales = scales or {}
    fuzzy_scale = scales.get("fuzzy", 1.0)
    quotient_scale = scales.get("quotient", 1.0)
    reliability_scale = scales.get("reliability", 1.0)
    state_scale = scales.get("state", 1.0)
    proto_scale = scales.get("proto", 1.0)
    entropy_scale = scales.get("entropy", 1.0)

    z_rna, z_atac, z, weights, u, dist2 = model(br, ba, args.temperature)

    loss_contrast = info_nce(z_rna, z_atac, args.contrast_temperature)
    loss_fuzzy = fuzzy_compactness(u, dist2, args.fuzzy_m)
    loss_quotient, _, _ = quotient_distance_loss(u, br, ba)

    loss_rel = reliability_loss(
        weights, u, z_rna, z_atac, model.prototypes, args.temperature, args.prior_rna
    )

    loss_bal = balance_loss(weights, args.prior_rna)

    loss_struct = (
        pairwise_structure_loss(z_rna, br)
        + pairwise_structure_loss(z_atac, ba)
        + pairwise_structure_loss(
            z,
            weights[:, 0:1].detach() * br + weights[:, 1:2].detach() * ba,
        )
    ) / 3.0

    loss_state_bal = state_balance_loss(u)
    loss_pair_mse = F.mse_loss(z_rna, z_atac)
    loss_proto_orth = prototype_orthogonality_loss(model.prototypes)

    # 🔥 NEW: 防止 U 变成均匀分布
    # 最小化 entropy => 让每个细胞更明确地属于少数 state
    loss_u_entropy = -(u * torch.log(u + 1e-8)).sum(dim=1).mean()

    loss = (
        args.lambda_contrast * loss_contrast
        + args.lambda_fuzzy * fuzzy_scale * loss_fuzzy
        + quotient_weight * quotient_scale * loss_quotient
        + args.lambda_reliability * reliability_scale * loss_rel
        + args.lambda_balance * loss_bal
        + args.lambda_structure * loss_struct
        + args.lambda_state_balance * state_scale * loss_state_bal
        + args.lambda_pair_mse * loss_pair_mse
        + args.lambda_proto_sep * proto_scale * loss_proto_orth
        + args.lambda_u_entropy * entropy_scale * loss_u_entropy
    )

    logs = {
        "loss": loss.item(),
        "contrast": loss_contrast.item(),
        "fuzzy": loss_fuzzy.item(),
        "quotient": loss_quotient.item(),
        "quotient_weight": float(quotient_weight),
        "fuzzy_scale": float(fuzzy_scale),
        "structure": loss_struct.item(),
        "reliability": loss_rel.item(),
        "balance": loss_bal.item(),
        "state_balance": loss_state_bal.item(),
        "pair_mse": loss_pair_mse.item(),
        "proto_orth": loss_proto_orth.item(),
        "u_entropy": loss_u_entropy.item(),
        "mean_rna_weight": weights[:, 0].mean().item(),
        "mean_atac_weight": weights[:, 1].mean().item(),
        "mean_max_membership": u.max(dim=1)[0].mean().item(),
    }

    return loss, logs


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--rna", default="rna_clean.h5ad")
    parser.add_argument("--atac", default="atac_clean.h5ad")
    parser.add_argument("--gene-peak", default="gene_peak.npz")
    parser.add_argument("--label-key", default="celltype")
    parser.add_argument("--out-dir", default="fqalign_out")
    parser.add_argument("--n-pcs", type=int, default=50)
    parser.add_argument("--z-dim", type=int, default=32)
    parser.add_argument("--states", type=int, default=12)
    parser.add_argument("--epochs", type=int, default=300)
    parser.add_argument("--batch-size", type=int, default=1024)
    parser.add_argument("--lr", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--eval-seeds", type=int, default=10)

    parser.add_argument("--temperature", type=float, default=0.12)
    parser.add_argument("--contrast-temperature", type=float, default=0.15)
    parser.add_argument("--fuzzy-m", type=float, default=1.6)

    parser.add_argument("--lambda-contrast", type=float, default=0.4)
    parser.add_argument("--lambda-fuzzy", type=float, default=0.25)
    parser.add_argument("--lambda-quotient", type=float, default=0.2)
    parser.add_argument("--quotient-warmup-epochs", type=int, default=0)
    parser.add_argument(
        "--pretrain-epochs",
        type=int,
        default=80,
        help="Train contrast/structure first, then initialize prototypes and enable fuzzy losses.",
    )
    parser.add_argument(
        "--prototype-init",
        choices=["random", "kmeans"],
        default="kmeans",
        help="KMeans prototype init after pretraining reduces bad seed collapse.",
    )
    parser.add_argument("--lambda-reliability", type=float, default=0.1)
    parser.add_argument("--lambda-balance", type=float, default=0.5)
    parser.add_argument("--lambda-structure", type=float, default=0.5)
    parser.add_argument("--lambda-state-balance", type=float, default=0.05)
    parser.add_argument("--lambda-pair-mse", type=float, default=0.03)
    parser.add_argument("--lambda-u-entropy", type=float, default=0.02)

    parser.add_argument("--lambda-proto-sep", type=float, default=0.1)
    parser.add_argument("--proto-sep-margin", type=float, default=0.3)
    parser.add_argument("--grad-clip", type=float, default=5.0)

    parser.add_argument("--prior-rna", type=float, default=0.65)

    parser.add_argument(
        "--final-embedding",
        choices=["learned", "raw_weighted", "cell_weighted", "hybrid", "cell_hybrid"],
        default="learned",
        help="Embedding used when --auto-final is off. Clean data often works best with pure learned z.",
    )
    parser.add_argument("--final-atac-weight", type=float, default=0.1)
    parser.add_argument("--final-z-weight", type=float, default=2.0)
    parser.add_argument("--final-u-weight", type=float, default=0.25)
    parser.add_argument(
        "--final-standardize",
        choices=["none", "all", "blocks"],
        default="blocks",
        help="'blocks' standardizes each block before weighting, so final weights remain meaningful.",
    )
    parser.add_argument(
        "--auto-final",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Evaluate learned/raw/hybrid/cell_hybrid candidates and save the best final embedding.",
    )

    args = parser.parse_args()

    set_seed(args.seed)
    os.makedirs(args.out_dir, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    rna, atac, x_rna_np, x_atac_np, labels, mask = load_paired_representations(
        args.data_dir, args.rna, args.atac, args.label_key, args.n_pcs, args.gene_peak
    )

    x_rna = torch.tensor(x_rna_np, device=device, dtype=torch.float32)
    x_atac = torch.tensor(x_atac_np, device=device, dtype=torch.float32)

    in_dim = x_rna_np.shape[1]
    model = FuzzyQuotientAlign(in_dim, args.z_dim, args.states).to(device)
    initialize_gate_prior(model, args.prior_rna)
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    n = x_rna.size(0)

    print("cells={}, labeled={}, device={}".format(n, mask.sum(), device))

    loss_history = []

    for epoch in range(1, args.epochs + 1):
        if epoch == args.pretrain_epochs + 1 and args.prototype_init == "kmeans":
            initialize_prototypes_from_kmeans(model, x_rna, x_atac, args)
            opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
            print(f"Initialized prototypes from KMeans at epoch {epoch - 1}; optimizer reset")

        in_pretrain = epoch <= args.pretrain_epochs
        if in_pretrain:
            phase_scales = {
                "fuzzy": 0.0,
                "quotient": 0.0,
                "reliability": 0.0,
                "state": 0.0,
                "proto": 0.0,
                "entropy": 0.0,
            }
        else:
            phase_scales = None

        if in_pretrain or (args.quotient_warmup_epochs > 0 and epoch <= args.quotient_warmup_epochs):
            quotient_weight = 0.0
        else:
            quotient_weight = args.lambda_quotient

        perm = torch.randperm(n, device=device)
        epoch_logs = []

        for start in range(0, n, args.batch_size):
            idx = perm[start:start + args.batch_size]
            br = x_rna[idx]
            ba = x_atac[idx]

            loss, logs = compute_losses(model, br, ba, args, quotient_weight, phase_scales)

            opt.zero_grad()
            loss.backward()
            if args.grad_clip and args.grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(model.parameters(), args.grad_clip)
            opt.step()

            epoch_logs.append(logs)

        mean_logs = {
            k: float(np.mean([row[k] for row in epoch_logs]))
            for k in epoch_logs[0].keys()
        }
        mean_logs["epoch"] = epoch
        loss_history.append(mean_logs)

        if epoch == 1 or epoch % 20 == 0:
            print(
                "epoch={epoch:04d} loss={loss:.4f} contrast={contrast:.4f} "
                "fuzzy={fuzzy:.4f} quotient={quotient:.4f} q_w={quotient_weight:.4f} "
                "struct={structure:.4f} rel={reliability:.4f} bal={balance:.4f} "
                "state_bal={state_balance:.4f} mean_w_rna={mean_rna_weight:.3f} "
                "max_u={mean_max_membership:.3f} proto_orth={proto_orth:.4f} u_ent={u_entropy:.4f}".format(**mean_logs)
            )

    model.eval()
    with torch.no_grad():
        z_rna, z_atac, z, weights, u, _ = model(x_rna, x_atac, args.temperature)

    if n > 20000:
        print(
            f"Skipping final full-cell quotient matrix for n={n} to avoid OOM; "
            "BMMC benchmark metrics and UMAP do not require this output."
        )
        loss_quotient = torch.tensor(float("nan"))
        q_rna = torch.full((args.states, args.states), float("nan"))
        q_atac = torch.full((args.states, args.states), float("nan"))
    else:
        with torch.no_grad():
            loss_quotient, q_rna, q_atac = quotient_distance_loss(u, x_rna, x_atac)

    learned_embedding = z.cpu().numpy()
    weights_np = weights.cpu().numpy()
    membership = u.cpu().numpy()

    if args.auto_final:
        auto_best, embedding, ranked_candidates = evaluate_final_candidates(
            x_rna_np,
            x_atac_np,
            learned_embedding,
            membership,
            weights_np,
            labels,
            mask,
            args.eval_seeds,
            args.final_standardize,
            args.out_dir,
        )
        final_method_name = "FuzzyQuotientAlign_auto"
        final_embedding_desc = auto_best["method"]

        print("\nTop final embedding candidates:")
        print(
            ranked_candidates[
                ["method", "ARI", "NMI", "AMI", "Sil_pred", "kmeans_seed"]
            ].head(10).to_string(index=False)
        )
    else:
        embedding = build_final_embedding(
            args.final_embedding,
            x_rna_np,
            x_atac_np,
            learned_embedding,
            membership,
            weights_np,
            args.final_atac_weight,
            args.final_z_weight,
            args.final_u_weight,
            args.final_standardize,
        )
        final_method_name = "FuzzyQuotientAlign"
        final_embedding_desc = args.final_embedding

    np.save(os.path.join(args.out_dir, "fqalign_embedding.npy"), embedding)
    np.save(os.path.join(args.out_dir, "fqalign_learned_z.npy"), learned_embedding)
    np.save(os.path.join(args.out_dir, "fqalign_modality_weights.npy"), weights_np)
    np.save(os.path.join(args.out_dir, "fqalign_membership.npy"), membership)
    np.save(os.path.join(args.out_dir, "quotient_distance_rna.npy"), q_rna.cpu().numpy())
    np.save(os.path.join(args.out_dir, "quotient_distance_atac.npy"), q_atac.cpu().numpy())

    cell_df, state_df, celltype_df, state_celltype_df = state_summary(
        rna.obs_names.values, labels, weights_np, membership
    )
    cell_df.to_csv(os.path.join(args.out_dir, "cell_modality_reliability.csv"), index=False)
    state_df.to_csv(os.path.join(args.out_dir, "state_modality_summary.csv"), index=False)
    celltype_df.to_csv(os.path.join(args.out_dir, "celltype_modality_summary.csv"), index=False)
    state_celltype_df.to_csv(os.path.join(args.out_dir, "state_celltype_composition.csv"), index=False)

    pd.DataFrame(loss_history).to_csv(os.path.join(args.out_dir, "loss_history.csv"), index=False)

    with open(os.path.join(args.out_dir, "run_config.json"), "w", encoding="utf-8") as f:
        json.dump(vars(args), f, indent=2)

    best, all_scores, summary = save_embedding_result(
        args.out_dir,
        final_method_name,
        embedding,
        labels,
        mask,
        seeds=args.eval_seeds,
        extra={
            "final_embedding": final_embedding_desc,
            "train_seed": args.seed,
            "final_standardize": args.final_standardize,
        },
    )

    best_z, all_scores_z, summary_z = save_embedding_result(
        args.out_dir,
        "FuzzyQuotientAlign_learned_z",
        learned_embedding,
        labels,
        mask,
        seeds=args.eval_seeds,
        extra={"final_embedding": "learned", "train_seed": args.seed},
    )

    all_scores.to_csv(os.path.join(args.out_dir, "metrics_by_seed.csv"), index=False)
    all_scores_z.to_csv(os.path.join(args.out_dir, "metrics_learned_z_by_seed.csv"), index=False)
    pd.DataFrame([best]).to_csv(os.path.join(args.out_dir, "metrics_best.csv"), index=False)
    pd.DataFrame([best_z]).to_csv(os.path.join(args.out_dir, "metrics_learned_z_best.csv"), index=False)

    print("\nFinal quotient loss: {:.6f}".format(loss_quotient.item()))
    print(
        "Best KMeans on final embedding ({}): ARI={:.4f} NMI={:.4f} AMI={:.4f} seed={}".format(
            final_embedding_desc,
            best["ARI"],
            best["NMI"],
            best["AMI"],
            int(best["kmeans_seed"]),
        )
    )
    print(
        "Best KMeans on pure learned z: ARI={:.4f} NMI={:.4f} AMI={:.4f} seed={}".format(
            best_z["ARI"],
            best_z["NMI"],
            best_z["AMI"],
            int(best_z["kmeans_seed"]),
        )
    )
    print("Saved outputs to:", args.out_dir)


if __name__ == "__main__":
    main()
