import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

CSV = "outputs/paper_figures/figure2/figure2_source_data.csv"
OUTDIR = "outputs/paper_figures/figure2"
os.makedirs(OUTDIR, exist_ok=True)

data = pd.read_csv(CSV)

datasets = ["PBMC-10K", "PBMC-3K", "SNARE-seq"]
methods = ["FQ-Align", "SCGLUE", "MultiVI", "Cobolt", "MOFA+"]
metrics = ["ARI", "NMI", "Silhouette"]

colors = {
    "FQ-Align": "#4C78A8",
    "SCGLUE": "#8A8A8A",
    "MultiVI": "#7F7F7F",
    "Cobolt": "#9E9E9E",
    "MOFA+": "#BDBDBD",
}

plt.rcParams.update({
    "font.family": "sans-serif",
    "font.size": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.linewidth": 1.0,
})

fig, axes = plt.subplots(
    nrows=len(datasets),
    ncols=len(metrics),
    figsize=(10.2, 7.8),
    sharey=False,
)

for i, dataset in enumerate(datasets):
    for j, metric in enumerate(metrics):
        ax = axes[i, j]
        sub = data[data["Dataset"] == dataset].set_index("Method")

        vals, used_methods = [], []
        for m in methods:
            if m in sub.index:
                vals.append(float(sub.loc[m, metric]))
                used_methods.append(m)

        vals = np.array(vals)
        x = np.arange(len(used_methods))

        best_idx = int(np.nanargmax(vals))

        edge_colors = []
        line_widths = []
        for idx, m in enumerate(used_methods):
            if idx == best_idx:
                edge_colors.append("#E63946")
                line_widths.append(2.4)
            else:
                edge_colors.append("none")
                line_widths.append(0.0)

        ax.bar(
            x,
            vals,
            color=[colors[m] for m in used_methods],
            edgecolor=edge_colors,
            linewidth=line_widths,
        )

        ax.set_ylim(0, 1.0)
        ax.set_xticks(x)
        ax.set_xticklabels(used_methods, rotation=45, ha="right", fontsize=8)
        ax.grid(axis="y", alpha=0.2, linewidth=0.8)

        if i == 0:
            ax.set_title(metric, fontsize=12)

        if j == 0:
            ax.set_ylabel(dataset, fontsize=11)

        for xi, v in zip(x, vals):
            ax.text(
                xi,
                min(v + 0.025, 0.97),
                f"{v:.2f}",
                ha="center",
                va="bottom",
                fontsize=7,
                rotation=90,
            )

plt.tight_layout()

plt.savefig(f"{OUTDIR}/Figure2a_benchmark.png", dpi=300, bbox_inches="tight")
plt.savefig(f"{OUTDIR}/Figure2a_benchmark.pdf", bbox_inches="tight")

print("Saved to:", OUTDIR)
print(data)
