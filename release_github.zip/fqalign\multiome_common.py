import json
import os
import warnings

import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.metrics import (
    adjusted_mutual_info_score,
    adjusted_rand_score,
    homogeneity_completeness_v_measure,
    normalized_mutual_info_score,
    silhouette_score,
)
from sklearn.preprocessing import StandardScaler


warnings.filterwarnings("ignore")


def as_dense(x):
    return x.toarray() if sp.issparse(x) else np.asarray(x)


def ensure_out_dir(path):
    os.makedirs(path, exist_ok=True)
    return path


def load_paired_h5ad(data_dir, rna_file, atac_file, label_key="celltype"):
    rna = sc.read_h5ad(os.path.join(data_dir, rna_file))
    atac = sc.read_h5ad(os.path.join(data_dir, atac_file))
    if not np.array_equal(rna.obs_names.values, atac.obs_names.values):
        common = rna.obs_names.intersection(atac.obs_names)
        if len(common) == 0:
            raise ValueError("RNA and ATAC have no shared obs_names.")
        rna = rna[common].copy()
        atac = atac[common].copy()
    if label_key not in rna.obs:
        raise KeyError(f"label_key={label_key!r} is not in RNA obs columns.")
    return rna, atac


def validate_gene_peak(gene_peak, rna, atac, require_match=True):
    if gene_peak is None:
        return None
    gp = sp.load_npz(gene_peak).tocsr()
    expected = (rna.n_vars, atac.n_vars)
    if gp.shape != expected:
        msg = f"gene_peak shape {gp.shape} does not match RNA/ATAC vars {expected}."
        if require_match:
            raise ValueError(msg)
        print("WARNING:", msg)
    return gp


def matrix_col_sums(x):
    if sp.issparse(x):
        return np.asarray(x.sum(axis=0)).ravel()
    return np.asarray(x).sum(axis=0)


def select_top_columns_by_sum(adata, n_top):
    n_top = min(int(n_top), adata.n_vars)
    if n_top <= 0 or n_top >= adata.n_vars:
        return np.arange(adata.n_vars)
    score = matrix_col_sums(adata.X)
    score = np.nan_to_num(score, nan=0.0, posinf=0.0, neginf=0.0)
    return np.argsort(score)[-n_top:]


def select_atac_features(atac, max_peaks=50000, gene_peak=None, mode="linked_plus_top"):
    if max_peaks is None or max_peaks <= 0 or max_peaks >= atac.n_vars:
        return np.arange(atac.n_vars)

    linked = np.array([], dtype=int)
    if gene_peak is not None:
        linked = np.unique(gene_peak.tocoo().col).astype(int)

    if mode == "top":
        chosen = select_top_columns_by_sum(atac, max_peaks)
    elif mode == "linked":
        chosen = linked[:max_peaks]
    elif mode == "linked_plus_top":
        remaining = max(0, max_peaks - linked.size)
        top = select_top_columns_by_sum(atac, remaining) if remaining > 0 else np.array([], dtype=int)
        chosen = np.unique(np.concatenate([linked, top]))[:max_peaks]
    else:
        raise ValueError(f"Unknown ATAC feature selection mode: {mode}")

    if chosen.size == 0:
        raise ValueError("ATAC feature selection produced zero peaks.")
    return np.sort(chosen)


def subset_atac_with_gene_peak(atac, gene_peak, peak_idx):
    peak_idx = np.asarray(peak_idx, dtype=int)
    gp = None if gene_peak is None else gene_peak[:, peak_idx].tocsr()
    return atac[:, peak_idx].copy(), gp


def compute_lsi(x, n_components, random_state=0):
    if not sp.issparse(x):
        x = sp.csr_matrix(x)
    x = x.astype("float32").tocsr()
    cell_sum = np.asarray(x.sum(axis=1)).ravel()
    cell_sum[cell_sum == 0] = 1.0
    x = sp.diags(1.0 / cell_sum).dot(x)
    df = np.asarray((x > 0).sum(axis=0)).ravel()
    idf = np.log(1.0 + x.shape[0] / (1.0 + df)).astype("float32")
    x = x.multiply(idf)
    return TruncatedSVD(n_components=n_components, random_state=random_state).fit_transform(x)


def rna_pca(rna, n_pcs=50, random_state=0):
    n = min(n_pcs, rna.n_obs - 1, rna.n_vars - 1)
    if n < 2:
        raise ValueError("RNA matrix is too small for PCA.")
    emb = PCA(n_components=n, random_state=random_state).fit_transform(as_dense(rna.X))
    return StandardScaler().fit_transform(emb).astype("float32")


def atac_lsi(atac, n_pcs=50, random_state=0):
    if "X_lsi" in atac.obsm:
        emb = np.asarray(atac.obsm["X_lsi"])
        if emb.shape[1] >= n_pcs + 1:
            emb = emb[:, 1 : n_pcs + 1]
        elif emb.shape[1] >= n_pcs:
            emb = emb[:, :n_pcs]
        else:
            raise ValueError(f"ATAC X_lsi has {emb.shape[1]} dims, fewer than {n_pcs}.")
    else:
        n = min(n_pcs + 1, atac.n_obs - 1, atac.n_vars - 1)
        if n < 3:
            raise ValueError("ATAC matrix is too small for LSI.")
        emb = compute_lsi(atac.X, n_components=n, random_state=random_state)
        emb = emb[:, 1 : min(n_pcs + 1, emb.shape[1])]
    return StandardScaler().fit_transform(emb).astype("float32")


def labels_and_mask(rna, label_key="celltype"):
    labels = rna.obs[label_key].astype(str).values
    mask = ~pd.isna(rna.obs[label_key].values) & (labels != "nan")
    return labels, mask


def evaluate_embedding(embedding, labels, mask, seeds=10, method="method", max_sil_cells=3000):
    y = labels[mask]
    if len(y) == 0:
        raise ValueError("No labeled cells were found.")
    n_clusters = len(np.unique(y))
    rows = []
    emb = np.asarray(embedding)
    for seed in range(seeds):
        pred_all = KMeans(n_clusters=n_clusters, n_init=20, random_state=seed).fit_predict(emb)
        pred = pred_all[mask]
        h, c, v = homogeneity_completeness_v_measure(y, pred)
        sil_pred = np.nan
        sil_label = np.nan
        idx = np.arange(mask.sum())
        if len(idx) > max_sil_cells:
            idx = np.random.default_rng(0).choice(idx, max_sil_cells, replace=False)
        try:
            sil_pred = silhouette_score(emb[mask][idx], pred[idx])
        except Exception:
            pass
        try:
            sil_label = silhouette_score(emb[mask][idx], y[idx])
        except Exception:
            pass
        rows.append(
            {
                "method": method,
                "kmeans_seed": seed,
                "seed": seed,
                "ARI": adjusted_rand_score(y, pred),
                "NMI": normalized_mutual_info_score(y, pred),
                "AMI": adjusted_mutual_info_score(y, pred),
                "Homo": h,
                "Compl": c,
                "V": v,
                "Sil_pred": sil_pred,
                "Sil_label": sil_label,
            }
        )
    df = pd.DataFrame(rows)
    best = df.loc[df["ARI"].idxmax()].to_dict()
    summary = df.groupby("method", as_index=False).agg(
        ARI_mean=("ARI", "mean"),
        ARI_std=("ARI", "std"),
        ARI_best=("ARI", "max"),
        NMI_mean=("NMI", "mean"),
        AMI_mean=("AMI", "mean"),
        Sil_pred_mean=("Sil_pred", "mean"),
        Sil_label_mean=("Sil_label", "mean"),
    )
    return best, df, summary


def save_embedding_result(out_dir, method, embedding, labels, mask, seeds=10, extra=None):
    ensure_out_dir(out_dir)
    emb_path = os.path.join(out_dir, f"{method}_embedding.npy")
    np.save(emb_path, np.asarray(embedding).astype("float32"))
    best, by_seed, summary = evaluate_embedding(embedding, labels, mask, seeds=seeds, method=method)
    by_seed.to_csv(os.path.join(out_dir, f"{method}_metrics_by_seed.csv"), index=False)
    pd.DataFrame([best]).to_csv(os.path.join(out_dir, f"{method}_metrics_best.csv"), index=False)
    summary.to_csv(os.path.join(out_dir, f"{method}_metrics_summary.csv"), index=False)
    meta = {"method": method, "embedding": emb_path}
    if extra:
        meta.update(extra)
    with open(os.path.join(out_dir, f"{method}_meta.json"), "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    return best, by_seed, summary
