import argparse
import os

import muon as mu
import numpy as np
import scanpy as sc
import scipy.sparse as sp
import scvi
import torch

from multiome_common import (
    labels_and_mask,
    load_paired_h5ad,
    save_embedding_result,
    select_atac_features,
    subset_atac_with_gene_peak,
    validate_gene_peak,
)


def expm1_nonnegative(adata, max_count=1e6):
    if sp.issparse(adata.X):
        adata.X = adata.X.copy()
        adata.X.data = np.nan_to_num(adata.X.data, nan=0.0, posinf=20.0, neginf=0.0)
        adata.X.data = np.clip(adata.X.data, 0, 20)
        adata.X.data = np.expm1(adata.X.data)
        adata.X.data = np.nan_to_num(adata.X.data, nan=0.0, posinf=max_count, neginf=0.0)
        adata.X.data = np.clip(adata.X.data, 0, max_count)
        adata.X.data = np.rint(adata.X.data).astype("float32")
        adata.X.eliminate_zeros()
    else:
        x = np.nan_to_num(np.asarray(adata.X), nan=0.0, posinf=20.0, neginf=0.0)
        x = np.clip(x, 0, 20)
        x = np.expm1(x)
        x = np.nan_to_num(x, nan=0.0, posinf=max_count, neginf=0.0)
        x = np.clip(x, 0, max_count)
        adata.X = np.rint(x).astype("float32")


def binarize(adata):
    if sp.issparse(adata.X):
        adata.X = adata.X.copy().astype("float32").tocsr()
        adata.X.data[:] = 1.0
    else:
        adata.X = sp.csr_matrix((np.asarray(adata.X) > 0).astype("float32"))


def is_probably_log1p(adata):
    x = adata.X.data if sp.issparse(adata.X) else np.asarray(adata.X).ravel()
    if x.size == 0:
        return False
    x = x[np.isfinite(x)]
    if x.size == 0:
        return False
    return np.nanpercentile(x, 99) < 20 and np.any(np.abs(x - np.rint(x)) > 1e-3)


def csr_float32_counts(adata, max_count=1e6):
    if not sp.issparse(adata.X):
        adata.X = sp.csr_matrix(np.asarray(adata.X))
    adata.X = adata.X.astype("float32").tocsr()
    adata.X.data = np.nan_to_num(adata.X.data, nan=0.0, posinf=max_count, neginf=0.0)
    adata.X.data = np.clip(adata.X.data, 0, max_count)
    adata.X.data = np.rint(adata.X.data).astype("float32")
    adata.X.eliminate_zeros()


def sanitize_obs_for_scvi(adata):
    for col in adata.obs.columns:
        if adata.obs[col].dtype == object:
            adata.obs[col] = adata.obs[col].astype(str)
    adata.obs_names = adata.obs_names.astype(str)
    adata.var_names = adata.var_names.astype(str)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--rna", default="rna_clean.h5ad")
    parser.add_argument("--atac", default="atac_clean.h5ad")
    parser.add_argument("--gene-peak", default="gene_peak.npz")
    parser.add_argument("--label-key", default="celltype")
    parser.add_argument("--out-dir", default="outputs/multivi")
    parser.add_argument("--n-latent", type=int, default=32)
    parser.add_argument("--max-epochs", type=int, default=200)
    parser.add_argument("--eval-seeds", type=int, default=10)
    parser.add_argument("--seed", type=int, default=0)
    parser.add_argument("--max-atac-peaks", type=int, default=30000)
    parser.add_argument(
        "--atac-selection",
        choices=["linked_plus_top", "linked", "top"],
        default="linked_plus_top",
        help="Feature subset used before MultiVI to avoid loading all 567k peaks.",
    )
    parser.add_argument("--batch-size", type=int, default=512)
    parser.add_argument("--lr", type=float, default=1e-4)
    parser.add_argument("--max-count", type=float, default=1e6)
    parser.add_argument(
        "--rna-is-log1p",
        action=argparse.BooleanOptionalAction,
        default=None,
        help="Whether RNA X is log1p normalized. Default auto-detects and converts to count-like values.",
    )
    args = parser.parse_args()

    rna, atac = load_paired_h5ad(args.data_dir, args.rna, args.atac, args.label_key)
    gene_peak = None
    if args.gene_peak:
        gene_peak = validate_gene_peak(os.path.join(args.data_dir, args.gene_peak), rna, atac, require_match=True)
        print(f"gene_peak matched: ({rna.n_vars}, {atac.n_vars}), nnz={gene_peak.nnz}")

    peak_idx = select_atac_features(
        atac,
        max_peaks=args.max_atac_peaks,
        gene_peak=gene_peak,
        mode=args.atac_selection,
    )
    if peak_idx.size < atac.n_vars:
        atac, gene_peak = subset_atac_with_gene_peak(atac, gene_peak, peak_idx)
        print(f"ATAC subset for MultiVI: {atac.shape}, linked_edges_kept={gene_peak.nnz if gene_peak is not None else 'NA'}")

    if args.rna_is_log1p is None:
        args.rna_is_log1p = is_probably_log1p(rna)
        print(f"RNA log1p auto-detected: {args.rna_is_log1p}")
    if args.rna_is_log1p:
        expm1_nonnegative(rna, max_count=args.max_count)
    csr_float32_counts(rna, max_count=args.max_count)
    binarize(atac)
    sanitize_obs_for_scvi(rna)
    sanitize_obs_for_scvi(atac)

    mdata = mu.MuData({"rna": rna, "atac": atac})
    mu.pp.intersect_obs(mdata)

    scvi.settings.seed = args.seed
    device = "cuda" if torch.cuda.is_available() else "cpu"
    scvi.settings.device = device
    print(f"Using device: {device}")

    try:
        scvi.model.MULTIVI.setup_mudata(
            mdata,
            modalities={"rna_layer": "rna", "atac_layer": "atac"},
        )
    except (RuntimeError, TypeError) as exc:
        if "Could not infer dtype of numpy.float32" not in str(exc):
            raise
        # Some anndata/scvi combinations choke on numpy scalar metadata in obs/uns.
        for mod in mdata.mod.values():
            mod.uns.clear()
            for key in list(mod.obs.columns):
                if mod.obs[key].map(type).eq(np.float32).any():
                    mod.obs[key] = mod.obs[key].astype(float)
        scvi.model.MULTIVI.setup_mudata(
            mdata,
            modalities={"rna_layer": "rna", "atac_layer": "atac"},
        )
    model = scvi.model.MULTIVI(mdata, n_latent=args.n_latent)
    train_kwargs = {
        "max_epochs": args.max_epochs,
        "accelerator": device,
        "plan_kwargs": {"lr": args.lr},
    }
    try:
        model.train(**train_kwargs, batch_size=args.batch_size)
    except TypeError:
        model.train(**train_kwargs)

    latent = model.get_latent_representation()
    labels, mask = labels_and_mask(mdata.mod["rna"], args.label_key)
    best, _, _ = save_embedding_result(
        args.out_dir,
        "MultiVI",
        latent,
        labels,
        mask,
        seeds=args.eval_seeds,
        extra={"train_seed": args.seed, "n_latent": args.n_latent},
    )
    print(
        f"MultiVI best_ARI={best['ARI']:.4f} "
        f"NMI={best['NMI']:.4f} Sil_pred={best['Sil_pred']:.4f}"
    )


if __name__ == "__main__":
    main()
