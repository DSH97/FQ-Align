import argparse
import os
import warnings

import networkx as nx
import numpy as np
import scanpy as sc
import scipy.sparse as sp
import scglue
from sklearn.feature_extraction.text import TfidfTransformer

from multiome_common import labels_and_mask, load_paired_h5ad, save_embedding_result, validate_gene_peak


warnings.filterwarnings("ignore")


def clean_nonnegative(adata):
    if sp.issparse(adata.X):
        adata.X = adata.X.copy().astype("float32")
        adata.X.data = np.nan_to_num(adata.X.data, nan=0.0, posinf=0.0, neginf=0.0)
        adata.X.data[adata.X.data < 0] = 0
    else:
        adata.X = np.nan_to_num(np.asarray(adata.X), nan=0.0, posinf=0.0, neginf=0.0).astype("float32")
        adata.X[adata.X < 0] = 0


def maybe_log_normalize_rna(rna):
    x = rna.X.data if sp.issparse(rna.X) else np.asarray(rna.X).ravel()
    if x.size and np.percentile(x, 99) >= 20:
        sc.pp.normalize_total(rna, target_sum=1e4)
        sc.pp.log1p(rna)


def unique_var_names(adata, prefix):
    names = adata.var_names.astype(str)
    if names.is_unique and not names.str.fullmatch(r"\d+").all():
        return
    adata.var_names = [f"{prefix}_{i}" for i in range(adata.n_vars)]


def build_guidance_from_gene_peak(gene_peak, rna, atac):
    gp = gene_peak.tocoo()
    expected = (rna.n_vars, atac.n_vars)
    if gp.shape != expected:
        raise ValueError(f"gene_peak shape {gp.shape} does not match RNA/ATAC vars {expected}.")
    graph = nx.Graph()
    graph.add_nodes_from(rna.var_names.astype(str))
    graph.add_nodes_from(atac.var_names.astype(str))
    genes = rna.var_names.astype(str).values
    peaks = atac.var_names.astype(str).values
    for i, j, v in zip(gp.row, gp.col, gp.data):
        graph.add_edge(genes[i], peaks[j], weight=float(v), sign=1)
    return graph


def subset_to_guided_features(rna, atac, gene_peak, min_gene_edges=1, min_peak_edges=1):
    gene_degree = np.asarray(gene_peak.getnnz(axis=1)).ravel()
    peak_degree = np.asarray(gene_peak.getnnz(axis=0)).ravel()
    gene_idx = np.where(gene_degree >= min_gene_edges)[0]
    peak_idx = np.where(peak_degree >= min_peak_edges)[0]
    if gene_idx.size == 0 or peak_idx.size == 0:
        raise ValueError(
            "No guided RNA/ATAC features remain. gene_peak is too sparse for SCGLUE."
        )
    rna = rna[:, gene_idx].copy()
    atac = atac[:, peak_idx].copy()
    gene_peak = gene_peak[gene_idx, :][:, peak_idx].tocsr()
    return rna, atac, gene_peak


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--rna", default="rna_clean.h5ad")
    parser.add_argument("--atac", default="atac_clean.h5ad")
    parser.add_argument("--gene-peak", default="gene_peak.npz")
    parser.add_argument("--label-key", default="celltype")
    parser.add_argument("--out-dir", default="outputs/scglue")
    parser.add_argument("--n-top-genes", type=int, default=0)
    parser.add_argument("--max-epochs", type=int, default=150)
    parser.add_argument("--patience", type=int, default=20)
    parser.add_argument("--eval-seeds", type=int, default=10)
    parser.add_argument(
        "--data-likelihood",
        choices=["Normal", "NB", "ZINB"],
        default="Normal",
        help="Use gaussian for log1p/TFIDF clean matrices; NB/ZINB require count-like data.",
    )
    parser.add_argument(
        "--guided-only",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Keep only genes and peaks with at least one gene_peak edge.",
    )
    args = parser.parse_args()

    rna, atac = load_paired_h5ad(args.data_dir, args.rna, args.atac, args.label_key)
    unique_var_names(rna, "gene")
    unique_var_names(atac, "peak")
    gene_peak_path = os.path.join(args.data_dir, args.gene_peak)
    gene_peak = validate_gene_peak(gene_peak_path, rna, atac, require_match=True)
    print(f"gene_peak matched: {gene_peak.shape}, nnz={gene_peak.nnz}")

    clean_nonnegative(rna)
    clean_nonnegative(atac)
    maybe_log_normalize_rna(rna)

    if args.guided_only:
        rna, atac, gene_peak = subset_to_guided_features(rna, atac, gene_peak)
        print(f"guided subset RNA={rna.shape}, ATAC={atac.shape}, edges={gene_peak.nnz}")

    if args.n_top_genes and args.n_top_genes > 0 and args.n_top_genes < rna.n_vars:
        try:
            sc.pp.highly_variable_genes(rna, n_top_genes=args.n_top_genes, flavor="seurat_v3")
        except Exception:
            sc.pp.highly_variable_genes(rna, n_top_genes=args.n_top_genes, flavor="cell_ranger")
        hv = np.asarray(rna.var["highly_variable"].values, dtype=bool)
        rna = rna[:, hv].copy()
        gene_peak = gene_peak[hv, :].tocsr()
        rna, atac, gene_peak = subset_to_guided_features(rna, atac, gene_peak)
        print(f"HVG guided subset RNA={rna.shape}, ATAC={atac.shape}, edges={gene_peak.nnz}")

    atac.X = TfidfTransformer().fit_transform(atac.X)
    clean_nonnegative(atac)

    guidance_path = os.path.join(args.out_dir, "gene_peak_guidance.graphml.gz")
    os.makedirs(args.out_dir, exist_ok=True)
    guidance = build_guidance_from_gene_peak(gene_peak, rna, atac)
    nx.write_graphml(guidance, guidance_path)
    print(f"guidance nodes={guidance.number_of_nodes()} edges={guidance.number_of_edges()}")

    scglue.models.configure_dataset(rna, args.data_likelihood, use_highly_variable=False)
    scglue.models.configure_dataset(atac, args.data_likelihood, use_highly_variable=False)

    fit_kws = {
        "directory": os.path.join(args.out_dir, "model"),
        "max_epochs": args.max_epochs,
        "patience": args.patience,
    }
    try:
        glue = scglue.models.fit_SCGLUE(
            {"rna": rna, "atac": atac},
            guidance,
            fit_kws={**fit_kws, "overwrite": True},
        )
    except TypeError as exc:
        if "overwrite" not in str(exc):
            raise
        glue = scglue.models.fit_SCGLUE(
            {"rna": rna, "atac": atac},
            guidance,
            fit_kws=fit_kws,
        )

    rna_emb = glue.encode_data("rna", rna)
    atac_emb = glue.encode_data("atac", atac)
    latent = (rna_emb + atac_emb) / 2.0
    labels, mask = labels_and_mask(rna, args.label_key)
    best, _, _ = save_embedding_result(
        args.out_dir,
        "SCGLUE_gene_peak",
        latent,
        labels,
        mask,
        seeds=args.eval_seeds,
    )
    print(
        f"SCGLUE best_ARI={best['ARI']:.4f} "
        f"NMI={best['NMI']:.4f} Sil_pred={best['Sil_pred']:.4f}"
    )


if __name__ == "__main__":
    main()
