import argparse
import os

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def clean_method(x):
    return str(x).replace("_BMMC", "").replace("_", " ")


def main():
    parser = argparse.ArgumentParser(description="Plot runtime and optional memory summary.")
    parser.add_argument("--csv", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--title", default="")
    parser.add_argument("--runtime-unit", choices=["seconds", "minutes", "hours"], default="hours")
    args = parser.parse_args()

    df = pd.read_csv(args.csv)
    if "method" not in df.columns or "runtime_seconds" not in df.columns:
        raise ValueError("CSV must contain at least method and runtime_seconds columns.")

    df = df.copy()
    df["method_label"] = df["method"].map(clean_method)
    df["runtime_seconds"] = pd.to_numeric(df["runtime_seconds"], errors="coerce")
    df = df.dropna(subset=["runtime_seconds"])

    unit_scale = {"seconds": 1.0, "minutes": 60.0, "hours": 3600.0}[args.runtime_unit]
    unit_label = {"seconds": "Runtime (s)", "minutes": "Runtime (min)", "hours": "Runtime (h)"}[
        args.runtime_unit
    ]
    df["runtime_plot"] = df["runtime_seconds"] / unit_scale
    df = df.sort_values("runtime_plot", ascending=True)

    mem_col = None
    for col in ["peak_memory_gb", "peak_rss_gb", "max_rss_gb"]:
        if col in df.columns:
            mem_col = col
            break
    if mem_col is None:
        for col in ["max_rss_kb", "peak_rss_kb"]:
            if col in df.columns:
                df["peak_memory_gb"] = pd.to_numeric(df[col], errors="coerce") / 1024 / 1024
                mem_col = "peak_memory_gb"
                break
    if mem_col is None:
        for col in ["peak_working_set_mb", "peak_private_memory_mb"]:
            if col in df.columns:
                df["peak_memory_gb"] = pd.to_numeric(df[col], errors="coerce") / 1024
                mem_col = "peak_memory_gb"
                break

    colors = {
        "FQ-Align": "#4C78A8",
        "SCGLUE": "#E45756",
        "MultiVI": "#F58518",
        "Cobolt": "#72B7B2",
        "MOFA": "#54A24B",
    }
    bar_colors = [colors.get(m, "#8E8E8E") for m in df["method_label"]]

    if mem_col and df[mem_col].notna().any():
        fig, axes = plt.subplots(1, 2, figsize=(8.8, 3.2))
        ax = axes[0]
    else:
        fig, ax = plt.subplots(figsize=(4.8, 3.2))
        axes = [ax]

    ax.barh(df["method_label"], df["runtime_plot"], color=bar_colors)
    ax.set_xlabel(unit_label)
    ax.set_ylabel("")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    for y, v in enumerate(df["runtime_plot"]):
        ax.text(v, y, f" {v:.2f}", va="center", fontsize=8)

    if mem_col and df[mem_col].notna().any():
        mem = pd.to_numeric(df[mem_col], errors="coerce")
        axes[1].barh(df["method_label"], mem, color=bar_colors)
        axes[1].set_xlabel("Peak memory (GB)")
        axes[1].set_ylabel("")
        axes[1].spines["top"].set_visible(False)
        axes[1].spines["right"].set_visible(False)
        for y, v in enumerate(mem):
            if np.isfinite(v):
                axes[1].text(v, y, f" {v:.2f}", va="center", fontsize=8)

    if args.title:
        fig.suptitle(args.title, y=1.02, fontsize=11)
    fig.tight_layout()
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    fig.savefig(args.out, dpi=300, bbox_inches="tight")
    fig.savefig(os.path.splitext(args.out)[0] + ".pdf", bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
