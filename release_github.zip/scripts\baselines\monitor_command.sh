#!/usr/bin/env bash
set -uo pipefail

if [ "$#" -lt 3 ]; then
  echo "Usage: bash scripts/monitor_command_poll_memory.sh METHOD OUT_DIR command..." >&2
  exit 2
fi

METHOD="$1"
OUT_DIR="$2"
shift 2

mkdir -p "$OUT_DIR"
STDOUT="$OUT_DIR/${METHOD}.stdout.log"
STDERR="$OUT_DIR/${METHOD}.stderr.log"
CSV="$OUT_DIR/runtime_memory.csv"
CMD_ESCAPED="$(printf '%q ' "$@")"

START_EPOCH="$(date +%s)"
START_ISO="$(date -Iseconds)"

"$@" >"$STDOUT" 2>"$STDERR" &
ROOT_PID=$!
PEAK_RSS_KB=0

while kill -0 "$ROOT_PID" 2>/dev/null; do
  PIDS="$ROOT_PID $(pgrep -P "$ROOT_PID" 2>/dev/null | tr '\n' ' ')"
  TOTAL=0
  for pid in $PIDS; do
    if [ -r "/proc/$pid/status" ]; then
      RSS=$(awk '/VmRSS:/ {print $2}' "/proc/$pid/status")
      RSS=${RSS:-0}
      TOTAL=$((TOTAL + RSS))
    fi
  done
  if [ "$TOTAL" -gt "$PEAK_RSS_KB" ]; then
    PEAK_RSS_KB="$TOTAL"
  fi
  sleep 2
done

wait "$ROOT_PID"
STATUS=$?
END_EPOCH="$(date +%s)"
END_ISO="$(date -Iseconds)"
RUNTIME="$((END_EPOCH - START_EPOCH))"

if [ ! -f "$CSV" ]; then
  echo "method,start_time,end_time,runtime_seconds,max_rss_kb,peak_memory_gb,exit_code,stdout,stderr,command" > "$CSV"
fi

PEAK_GB=$(awk -v kb="$PEAK_RSS_KB" 'BEGIN {printf "%.4f", kb/1024/1024}')
echo "\"$METHOD\",\"$START_ISO\",\"$END_ISO\",$RUNTIME,$PEAK_RSS_KB,$PEAK_GB,$STATUS,\"$STDOUT\",\"$STDERR\",\"$CMD_ESCAPED\"" >> "$CSV"
echo "method=$METHOD runtime_seconds=$RUNTIME peak_memory_gb=$PEAK_GB exit_code=$STATUS"
exit "$STATUS"
