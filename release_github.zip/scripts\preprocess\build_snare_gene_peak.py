import os
import re
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp


DATA = "/iei4/scCFMD/data_snare/processed"
GTF = "/iei4/scCFMD/data_snare/raw/gencode.vM38.basic.annotation.gtf"  # 如果没有这个文件，下面会自动用近邻简化版
OUT = os.path.join(DATA, "gene_peak.npz")


def parse_peak(p):
    m = re.match(r"(.+):(\d+)-(\d+)", str(p))
    if m is None:
        return None
    return m.group(1), int(m.group(2)), int(m.group(3))


def load_gene_tss(gtf_path, genes_keep):
    rows = []
    with open(gtf_path) as f:
        for line in f:
            if line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 9 or parts[2] != "gene":
                continue

            chrom, start, end, strand, attr = parts[0], int(parts[3]), int(parts[4]), parts[6], parts[8]
            gene_name = None
            for item in attr.split(";"):
                item = item.strip()
                if item.startswith("gene_name"):
                    gene_name = item.split('"')[1]
                    break

            if gene_name is None or gene_name not in genes_keep:
                continue

            tss = start if strand == "+" else end
            rows.append((chrom, tss, gene_name))

    return pd.DataFrame(rows, columns=["chrom", "tss", "gene"])


def build_by_tss_window(rna, atac, gtf_path, window=150000):
    genes_keep = set(rna.var_names.astype(str))
    gene_tss = load_gene_tss(gtf_path, genes_keep)

    print("Loaded gene TSS:", gene_tss.shape)

    gene_to_idx = {g: i for i, g in enumerate(rna.var_names.astype(str))}
    peak_rows = []
    for j, p in enumerate(atac.var_names.astype(str)):
        parsed = parse_peak(p)
        if parsed is None:
            continue
        chrom, start, end = parsed
        mid = (start + end) // 2
        peak_rows.append((j, chrom, mid))

    peaks = pd.DataFrame(peak_rows, columns=["peak_idx", "chrom", "mid"])
    print("Parsed peaks:", peaks.shape)

    rows, cols = [], []

    for chrom in sorted(set(peaks["chrom"]).intersection(set(gene_tss["chrom"]))):
        gsub = gene_tss[gene_tss["chrom"] == chrom]
        psub = peaks[peaks["chrom"] == chrom]

        g_tss = gsub["tss"].values
        g_gene = gsub["gene"].values

        for peak_idx, mid in zip(psub["peak_idx"].values, psub["mid"].values):
            lo, hi = mid - window, mid + window
            hit = np.where((g_tss >= lo) & (g_tss <= hi))[0]
            for h in hit:
                rows.append(gene_to_idx[g_gene[h]])
                cols.append(peak_idx)

    mat = sp.coo_matrix(
        (np.ones(len(rows), dtype=np.float32), (rows, cols)),
        shape=(rna.n_vars, atac.n_vars),
    ).tocsr()

    mat.data[:] = 1.0
    mat.eliminate_zeros()
    return mat


def build_fallback_empty(rna, atac):
    print("[WARN] No GTF found. Creating empty gene_peak matrix.")
    return sp.csr_matrix((rna.n_vars, atac.n_vars), dtype=np.float32)


def main():
    rna = sc.read_h5ad(os.path.join(DATA, "rna_clean.h5ad"))
    atac = sc.read_h5ad(os.path.join(DATA, "atac_clean.h5ad"))

    print("RNA:", rna.shape)
    print("ATAC:", atac.shape)

    if os.path.exists(GTF):
        gene_peak = build_by_tss_window(rna, atac, GTF, window=150000)
    else:
        gene_peak = build_fallback_empty(rna, atac)

    print("gene_peak:", gene_peak.shape, "nnz=", gene_peak.nnz)

    sp.save_npz(OUT, gene_peak)
    print("Saved:", OUT)


if __name__ == "__main__":
    main()