import argparse
import json
import os
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp


RNA_VALUES = {
    "gene expression",
    "gex",
    "rna",
    "rna-seq",
    "scrna",
    "expression",
}
ATAC_VALUES = {
    "peaks",
    "peak",
    "atac",
    "atac-seq",
    "scatac",
    "accessibility",
}


def norm_value(x):
    return str(x).strip().lower().replace("_", " ").replace("-", " ")


def pick_column(df, candidates, required=True):
    lower = {c.lower(): c for c in df.columns}
    for name in candidates:
        if name.lower() in lower:
            return lower[name.lower()]
    for col in df.columns:
        c = col.lower()
        if any(name.lower() in c for name in candidates):
            return col
    if required:
        raise KeyError(f"Could not find any of {candidates} in columns: {list(df.columns)}")
    return None


def infer_feature_type_column(var):
    candidates = [
        "feature_types",
        "feature_type",
        "feature type",
        "modality",
        "mod",
        "omic",
        "assay",
        "type",
    ]
    return pick_column(var, candidates)


def infer_label_column(obs, requested=None):
    if requested and requested in obs.columns:
        return requested
    candidates = [
        "cell_type",
        "celltype",
        "cell type",
        "cell_type_l2",
        "cell_type_l1",
        "cell_label",
        "label",
        "labels",
        "annotation",
    ]
    return pick_column(obs, candidates)


def sanitize_for_h5ad(adata):
    adata.obs_names = adata.obs_names.astype(str)
    adata.var_names = adata.var_names.astype(str)
    for col in adata.obs.columns:
        if pd.api.types.is_object_dtype(adata.obs[col]):
            adata.obs[col] = adata.obs[col].astype(str)
    for col in adata.var.columns:
        if pd.api.types.is_object_dtype(adata.var[col]):
            adata.var[col] = adata.var[col].astype(str)
    if not sp.issparse(adata.X):
        adata.X = np.asarray(adata.X, dtype=np.float32)
    else:
        adata.X = adata.X.astype(np.float32).tocsr()
    return adata


def main():
    parser = argparse.ArgumentParser(
        description="Split an OpenProblems/BMMC multiome h5ad into paired RNA and ATAC h5ad files."
    )
    parser.add_argument("--input", required=True, help="Input processed OpenProblems/BMMC .h5ad")
    parser.add_argument("--out-dir", required=True, help="Output directory")
    parser.add_argument("--label-key", default=None, help="Cell-type label column. Auto-detected if omitted.")
    parser.add_argument("--feature-type-key", default=None, help="var column marking RNA/ATAC features.")
    parser.add_argument("--rna-out", default="rna_clean.h5ad")
    parser.add_argument("--atac-out", default="atac_clean.h5ad")
    parser.add_argument("--canonical-label", default="celltype")
    args = parser.parse_args()

    input_path = Path(args.input)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    adata = ad.read_h5ad(input_path)
    feature_col = args.feature_type_key or infer_feature_type_column(adata.var)
    label_col = infer_label_column(adata.obs, args.label_key)

    ft = adata.var[feature_col].map(norm_value)
    rna_mask = ft.isin(RNA_VALUES) | ft.str.contains("gene", na=False)
    atac_mask = ft.isin(ATAC_VALUES) | ft.str.contains("peak|atac", regex=True, na=False)

    if int(rna_mask.sum()) == 0 or int(atac_mask.sum()) == 0:
        counts = adata.var[feature_col].astype(str).value_counts().to_dict()
        raise ValueError(
            f"Could not split modalities using var[{feature_col!r}]. "
            f"Observed values: {counts}"
        )

    rna = adata[:, np.asarray(rna_mask)].copy()
    atac = adata[:, np.asarray(atac_mask)].copy()

    rna.obs[args.canonical_label] = adata.obs[label_col].astype(str).values
    atac.obs[args.canonical_label] = adata.obs[label_col].astype(str).values

    rna = sanitize_for_h5ad(rna)
    atac = sanitize_for_h5ad(atac)
    rna.write_h5ad(out_dir / args.rna_out, compression="gzip")
    atac.write_h5ad(out_dir / args.atac_out, compression="gzip")

    meta = {
        "input": str(input_path),
        "n_cells": int(adata.n_obs),
        "n_features_total": int(adata.n_vars),
        "feature_type_key": feature_col,
        "label_key_original": label_col,
        "label_key_output": args.canonical_label,
        "n_rna_features": int(rna.n_vars),
        "n_atac_features": int(atac.n_vars),
        "n_labels": int(pd.Series(rna.obs[args.canonical_label]).nunique()),
        "label_counts": pd.Series(rna.obs[args.canonical_label]).value_counts().to_dict(),
        "rna_out": str(out_dir / args.rna_out),
        "atac_out": str(out_dir / args.atac_out),
    }
    with open(out_dir / "bmmc_prepare_metadata.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    print(json.dumps(meta, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
