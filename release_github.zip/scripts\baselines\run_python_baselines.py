import argparse
import os

import numpy as np

from multiome_common import (
    atac_lsi,
    labels_and_mask,
    load_paired_h5ad,
    rna_pca,
    save_embedding_result,
    validate_gene_peak,
)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--rna", default="rna_clean.h5ad")
    parser.add_argument("--atac", default="atac_clean.h5ad")
    parser.add_argument("--gene-peak", default="gene_peak.npz")
    parser.add_argument("--label-key", default="celltype")
    parser.add_argument("--out-dir", default="outputs/baselines")
    parser.add_argument("--n-pcs", type=int, default=50)
    parser.add_argument("--eval-seeds", type=int, default=10)
    parser.add_argument(
        "--weighted-alphas",
        type=float,
        nargs="+",
        default=[0.01, 0.02, 0.05, 0.1, 0.2, 0.5, 0.7, 1.0],
        help="ATAC weights for concat([RNA_PCA, alpha * ATAC_LSI]).",
    )
    parser.add_argument(
        "--extra-embedding",
        action="append",
        default=[],
        help="Optional NAME=PATH .npy embedding to evaluate with the same metrics.",
    )
    args = parser.parse_args()

    rna, atac = load_paired_h5ad(args.data_dir, args.rna, args.atac, args.label_key)
    if args.gene_peak:
        validate_gene_peak(os.path.join(args.data_dir, args.gene_peak), rna, atac, require_match=True)
        print(f"gene_peak matched: ({rna.n_vars}, {atac.n_vars})")

    labels, mask = labels_and_mask(rna, args.label_key)
    x_rna = rna_pca(rna, n_pcs=args.n_pcs)
    x_atac = atac_lsi(atac, n_pcs=args.n_pcs)
    min_dim = min(x_rna.shape[1], x_atac.shape[1])
    x_rna = x_rna[:, :min_dim]
    x_atac = x_atac[:, :min_dim]

    all_summaries = []
    methods = {
        "RNA_PCA": x_rna,
        "ATAC_LSI": x_atac,
        "Concat_PCA_LSI": np.hstack([x_rna, x_atac]),
    }
    for alpha in args.weighted_alphas:
        methods[f"WeightedConcat_atac_{alpha:g}"] = np.hstack([x_rna, alpha * x_atac])

    for method, emb in methods.items():
        best, _, summary = save_embedding_result(
            args.out_dir, method, emb, labels, mask, seeds=args.eval_seeds
        )
        all_summaries.append(summary)
        print(
            f"{method:28s} best_ARI={best['ARI']:.4f} "
            f"NMI={best['NMI']:.4f} Sil_pred={best['Sil_pred']:.4f}"
        )

    for spec in args.extra_embedding:
        if "=" not in spec:
            raise ValueError("--extra-embedding must be NAME=PATH")
        name, path = spec.split("=", 1)
        if not os.path.isabs(path):
            path = os.path.join(args.data_dir, path)
        emb = np.load(path)
        if emb.shape[0] != rna.n_obs:
            raise ValueError(f"{name} has {emb.shape[0]} cells, expected {rna.n_obs}.")
        best, _, summary = save_embedding_result(
            args.out_dir, name, emb, labels, mask, seeds=args.eval_seeds
        )
        all_summaries.append(summary)
        print(
            f"{name:28s} best_ARI={best['ARI']:.4f} "
            f"NMI={best['NMI']:.4f} Sil_pred={best['Sil_pred']:.4f}"
        )

    if all_summaries:
        import pandas as pd

        pd.concat(all_summaries, ignore_index=True).sort_values(
            "ARI_mean", ascending=False
        ).to_csv(os.path.join(args.out_dir, "baseline_summary.csv"), index=False)


if __name__ == "__main__":
    main()
