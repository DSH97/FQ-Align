import os
import glob
import pandas as pd
import matplotlib.pyplot as plt

OUT = "outputs/paper_figures/robustness"
os.makedirs(OUT, exist_ok=True)

def collect(pattern):
    rows = []
    for d in sorted(glob.glob(pattern)):
        csv = os.path.join(d, "metrics_best.csv")
        if not os.path.exists(csv):
            print("[MISS]", csv)
            continue

        df = pd.read_csv(csv)
        if df.empty:
            continue

        value = os.path.basename(d).split("_", 1)[1]
        rows.append({
            "param": float(value),
            "ARI": float(df["ARI"].iloc[0]),
            "NMI": float(df["NMI"].iloc[0]),
        })

    if not rows:
        return pd.DataFrame(columns=["param", "ARI", "NMI"])

    return pd.DataFrame(rows).sort_values("param")

df_k = collect("outputs/hparam_sweep/K_*")
df_lq = collect("outputs/hparam_sweep/lq_*")
df_tau = collect("outputs/hparam_sweep/tau_*")

fig, axes = plt.subplots(1, 3, figsize=(11, 3.5))

configs = [
    (df_k, "Number of fuzzy states K"),
    (df_lq, r"Quotient weight $\lambda_q$"),
    (df_tau, r"Temperature $\tau$"),
]

for ax, (df, title) in zip(axes, configs):
    if df.empty:
        ax.text(0.5, 0.5, "No results", ha="center", va="center")
        ax.set_title(title)
        continue

    ax.plot(df["param"], df["ARI"], marker="o", label="ARI")
    ax.plot(df["param"], df["NMI"], marker="s", label="NMI")
    ax.set_title(title, fontsize=12)
    ax.set_ylabel("Score")
    ax.set_ylim(0.4, 0.9)
    ax.grid(alpha=0.3)

axes[0].legend(frameon=False)
plt.tight_layout()

plt.savefig(os.path.join(OUT, "FigureS_hparam_sensitivity.png"), dpi=300, bbox_inches="tight")
plt.savefig(os.path.join(OUT, "FigureS_hparam_sensitivity.pdf"), bbox_inches="tight")

print("Saved to:", OUT)
print("K sweep:\n", df_k)
print("lambda_q sweep:\n", df_lq)
print("tau sweep:\n", df_tau)
