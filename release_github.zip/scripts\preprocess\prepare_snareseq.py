import os
import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
from scipy.io import mmread


RAW = "/iei4/scCFMD/data_snare/raw"
OUT = "/iei4/scCFMD/data_snare/processed"
os.makedirs(OUT, exist_ok=True)


def read_tsv(path):
    return pd.read_csv(path, header=None, sep="\t")


print("Loading RNA matrix...")
rna_mtx = mmread(
    os.path.join(RAW, "GSE126074_AdBrainCortex_SNAREseq_cDNA.counts.mtx.gz")
).tocsr()

rna_genes = read_tsv(
    os.path.join(RAW, "GSE126074_AdBrainCortex_SNAREseq_cDNA.genes.tsv.gz")
)

rna_barcodes = read_tsv(
    os.path.join(RAW, "GSE126074_AdBrainCortex_SNAREseq_cDNA.barcodes.tsv.gz")
)

print("Loading ATAC matrix...")
atac_mtx = mmread(
    os.path.join(RAW, "GSE126074_AdBrainCortex_SNAREseq_chromatin.counts.mtx.gz")
).tocsr()

atac_peaks = read_tsv(
    os.path.join(RAW, "GSE126074_AdBrainCortex_SNAREseq_chromatin.peaks.tsv.gz")
)

atac_barcodes = read_tsv(
    os.path.join(RAW, "GSE126074_AdBrainCortex_SNAREseq_chromatin.barcodes.tsv.gz")
)

print("RNA raw:", rna_mtx.shape)
print("ATAC raw:", atac_mtx.shape)

# matrices are features x cells, transpose to cells x features
rna_mtx = rna_mtx.T.tocsr()
atac_mtx = atac_mtx.T.tocsr()

rna_cells = pd.Index(rna_barcodes[0].astype(str).values)
atac_cells = pd.Index(atac_barcodes[0].astype(str).values)

common = rna_cells.intersection(atac_cells)
common = pd.Index(common.astype(str).values, name=None)

print("Common paired cells:", len(common))

rna_idx = rna_cells.get_indexer(common)
atac_idx = atac_cells.get_indexer(common)

rna_mtx = rna_mtx[rna_idx, :]
atac_mtx = atac_mtx[atac_idx, :]

# RNA genes
if rna_genes.shape[1] >= 2:
    gene_names = rna_genes[1].astype(str).values
else:
    gene_names = rna_genes[0].astype(str).values

# ATAC peaks
if atac_peaks.shape[1] >= 3:
    peak_names = [
        f"{c}:{int(s)}-{int(e)}"
        for c, s, e in zip(atac_peaks[0], atac_peaks[1], atac_peaks[2])
    ]
else:
    peak_names = atac_peaks[0].astype(str).values

rna = sc.AnnData(rna_mtx)
rna.obs_names = common.tolist()
rna.var_names = gene_names
rna.var_names_make_unique()

atac = sc.AnnData(atac_mtx)
atac.obs_names = common.tolist()
atac.var_names = list(map(str, peak_names))
atac.var_names_make_unique()

print("RNA AnnData:", rna.shape)
print("ATAC AnnData:", atac.shape)

# ATAC binarize
if sp.issparse(atac.X):
    atac.X = atac.X.tocsr().astype(np.float32)
    atac.X.data[:] = 1.0
else:
    atac.X = (atac.X > 0).astype(np.float32)

# placeholder labels; next step will replace by Allen transfer / marker labels
rna.obs["celltype"] = "unknown"
atac.obs["celltype"] = "unknown"

print("RNA preprocessing...")
rna.layers["counts"] = rna.X.copy()

sc.pp.filter_genes(rna, min_cells=5)

sc.pp.normalize_total(rna, target_sum=1e4)
sc.pp.log1p(rna)

try:
    sc.pp.highly_variable_genes(
        rna,
        n_top_genes=3000,
        flavor="seurat_v3",
        layer="counts",
        subset=False,
    )
except Exception as e:
    print("[WARN] seurat_v3 failed, fallback to cell_ranger:", e)
    sc.pp.highly_variable_genes(
        rna,
        n_top_genes=3000,
        flavor="cell_ranger",
        subset=False,
    )

rna = rna[:, rna.var["highly_variable"]].copy()
rna.X = rna.X.astype(np.float32)

print("RNA final:", rna.shape)
print("ATAC final:", atac.shape)

rna.write_h5ad(os.path.join(OUT, "rna_clean.h5ad"))
atac.write_h5ad(os.path.join(OUT, "atac_clean.h5ad"))

print("Saved:")
print(os.path.join(OUT, "rna_clean.h5ad"))
print(os.path.join(OUT, "atac_clean.h5ad"))