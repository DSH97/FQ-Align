import argparse
import os

import numpy as np
import pandas as pd
import scanpy as sc
import scipy.sparse as sp
from mofapy2.run.entry_point import entry_point
from sklearn.preprocessing import StandardScaler

from multiome_common import (
    as_dense,
    labels_and_mask,
    load_paired_h5ad,
    save_embedding_result,
    select_atac_features,
    select_top_columns_by_sum,
    subset_atac_with_gene_peak,
    validate_gene_peak,
)


def scale_dense_view(x):
    x = as_dense(x).astype("float32")
    x = np.nan_to_num(x, nan=0.0, posinf=0.0, neginf=0.0)
    return StandardScaler(with_mean=True, with_std=True).fit_transform(x).astype("float32")


def get_mofa_factors(ent):
    candidates = []
    try:
        candidates.append(ent.model.nodes["Z"].getExpectation())
    except Exception:
        pass
    try:
        candidates.append(ent.model.nodes["Z"].getExpectations()["E"])
    except Exception:
        pass
    try:
        candidates.append(ent.model.nodes["Z"].E)
    except Exception:
        pass
    for z in candidates:
        arr = np.asarray(z)
        if arr.ndim == 2:
            return arr.T if arr.shape[0] < arr.shape[1] else arr
    raise RuntimeError("Could not extract MOFA factors from mofapy2 model object.")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", default=".")
    parser.add_argument("--rna", default="rna_clean.h5ad")
    parser.add_argument("--atac", default="atac_clean.h5ad")
    parser.add_argument("--gene-peak", default="gene_peak.npz")
    parser.add_argument("--label-key", default="celltype")
    parser.add_argument("--out-dir", default="outputs/mofa")
    parser.add_argument("--n-rna-features", type=int, default=2000)
    parser.add_argument("--n-atac-peaks", type=int, default=5000)
    parser.add_argument("--n-factors", type=int, default=32)
    parser.add_argument("--max-iter", type=int, default=1000)
    parser.add_argument("--eval-seeds", type=int, default=10)
    parser.add_argument("--seed", type=int, default=0)
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    rna, atac = load_paired_h5ad(args.data_dir, args.rna, args.atac, args.label_key)
    gene_peak = validate_gene_peak(os.path.join(args.data_dir, args.gene_peak), rna, atac, require_match=True)

    gene_idx = select_top_columns_by_sum(rna, args.n_rna_features)
    rna = rna[:, gene_idx].copy()
    gene_peak = gene_peak[gene_idx, :].tocsr()

    peak_idx = select_atac_features(atac, args.n_atac_peaks, gene_peak=gene_peak, mode="linked_plus_top")
    atac, gene_peak = subset_atac_with_gene_peak(atac, gene_peak, peak_idx)
    print(f"MOFA feature subset RNA={rna.shape}, ATAC={atac.shape}, linked_edges={gene_peak.nnz}")

    rna_x = scale_dense_view(rna.X)
    atac_x = scale_dense_view(atac.X)

    samples = rna.obs_names.astype(str).tolist()
    data = [[rna_x], [atac_x]]
    ent = entry_point()
    ent.set_data_options(scale_views=False, scale_groups=False)
    ent.set_data_matrix(
        data,
        views_names=["rna", "atac"],
        groups_names=["paired"],
        samples_names=[samples],
        features_names=[rna.var_names.astype(str).tolist(), atac.var_names.astype(str).tolist()],
        likelihoods=["gaussian", "gaussian"],
    )
    ent.set_model_options(factors=args.n_factors)
    ent.set_train_options(iter=args.max_iter, seed=args.seed, convergence_mode="medium")
    ent.build()
    ent.run()

    try:
        ent.save(os.path.join(args.out_dir, "mofa_model.hdf5"))
    except Exception as exc:
        print(f"WARNING: failed to save MOFA model: {exc}")

    latent = get_mofa_factors(ent)
    if latent.shape[0] != rna.n_obs:
        raise ValueError(f"MOFA latent has {latent.shape[0]} cells, expected {rna.n_obs}.")
    labels, mask = labels_and_mask(rna, args.label_key)
    best, _, _ = save_embedding_result(
        args.out_dir,
        "MOFAplus",
        latent,
        labels,
        mask,
        seeds=args.eval_seeds,
        extra={
            "n_rna_features": args.n_rna_features,
            "n_atac_peaks": args.n_atac_peaks,
            "n_factors": args.n_factors,
        },
    )
    print(f"MOFA+ best_ARI={best['ARI']:.4f} NMI={best['NMI']:.4f} Sil_pred={best['Sil_pred']:.4f}")


if __name__ == "__main__":
    main()
