# FQ-Align

FQ-Align is a fuzzy quotient-space alignment framework for paired single-cell RNA-ATAC integration. The repository is intended to reproduce the method implementation, benchmark commands and state-level diagnostic analyses reported in the manuscript.

## What is included

- `fqalign/`
  - `fuzzy_quotient_align.py`: main FQ-Align implementation.
  - `multiome_common.py`: shared data loading, preprocessing and evaluation utilities.
- `scripts/preprocess/`
  - public dataset preprocessing and gene-peak prior construction scripts.
- `scripts/baselines/`
  - baseline wrappers and runtime/memory monitoring scripts.
  - Baseline methods use their official implementations; their source code is not redistributed here.
- `scripts/analysis/`
  - metric collection, quotient residual analysis, perturbation analysis and seed8 state-pair follow-up scripts.
- `scripts/figures/`
  - scripts used to generate benchmark, robustness and residual-validation figures.
- `configs/`
  - environment files for baseline methods and case-analysis settings.
- `paper_source_data/`
  - small CSV files used as examples for figure/source-data reproduction.

Large processed objects, raw public datasets, model checkpoints and manuscript figures are not included in the GitHub code package.

## Installation

```bash
conda env create -f environment.yml
conda activate fqalign
```

or install the Python dependencies manually:

```bash
pip install -r requirements.txt
```

Different baseline methods may require separate environments. Example environment files are provided in `configs/`.

## Minimal FQ-Align run

Input files should be paired RNA and ATAC `.h5ad` objects with matching cell barcodes.

```bash
python fqalign/fuzzy_quotient_align.py \
  --data-dir /path/to/processed_data \
  --rna rna_clean.h5ad \
  --atac atac_clean.h5ad \
  --gene-peak gene_peak.npz \
  --label-key celltype \
  --out-dir outputs/fqalign \
  --states 12 \
  --epochs 300 \
  --eval-seeds 10 \
  --auto-final
```

The script writes the integrated embedding, modality weights, fuzzy memberships, quotient matrices and clustering metrics to the output directory.

## Public datasets

The raw datasets are public and should be downloaded from their original sources:

- PBMC-10K: 10x Genomics Single Cell Multiome ATAC + Gene Expression dataset.
- PBMC-3K: 10x Genomics Single Cell Multiome ATAC + Gene Expression dataset.
- SNARE-seq: public SNARE-seq dataset described in the manuscript.
- BMMC: Open Problems multiome BMMC benchmark dataset.

This repository does not redistribute the large raw `.h5ad` files.

## Reproducibility notes

- Main FQ-Align outputs can be reproduced with `fqalign/fuzzy_quotient_align.py`.
- Baseline scripts are provided for transparency but depend on separately installed official packages.
- Figure source data and supplementary data are archived separately in the Zenodo package associated with the manuscript.
- Before public release, choose and add an appropriate open-source license.

