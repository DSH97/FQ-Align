#!/usr/bin/env python3
"""Cell-removal perturbation test for quotient and centroid residual rankings.

The trained seed8 model is kept fixed. For each repetition, a common set of
random cell pairs is used to estimate quotient geometry before and after
removing a fraction of cells. Common random numbers reduce Monte Carlo noise
in the perturbation comparison.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from scipy.stats import spearmanr


EPS = 1e-12


def upper_values(matrix: np.ndarray) -> np.ndarray:
    return matrix[np.triu_indices(matrix.shape[0], k=1)]


def ranked_pairs(matrix: np.ndarray) -> list[tuple[int, int, float]]:
    rows = [
        (i, j, float(matrix[i, j]))
        for i, j in combinations(range(matrix.shape[0]), 2)
    ]
    return sorted(rows, key=lambda row: row[2], reverse=True)


def pair_set(matrix: np.ndarray, top_k: int) -> set[tuple[int, int]]:
    return {(i, j) for i, j, _ in ranked_pairs(matrix)[:top_k]}


def pair_rank(matrix: np.ndarray, pair: tuple[int, int]) -> int:
    lookup = {
        (i, j): rank
        for rank, (i, j, _) in enumerate(ranked_pairs(matrix), start=1)
    }
    return lookup[tuple(sorted(pair))]


def jaccard(a: set, b: set) -> float:
    return len(a & b) / max(len(a | b), 1)


def fuzzy_centroid_residual(
    rna: np.ndarray, atac: np.ndarray, membership: np.ndarray
) -> np.ndarray:
    mass = membership.sum(axis=0) + EPS
    rna_centroids = membership.T @ rna / mass[:, None]
    atac_centroids = membership.T @ atac / mass[:, None]
    rna_dist = cdist(rna_centroids, rna_centroids)
    atac_dist = cdist(atac_centroids, atac_centroids)
    rna_dist /= np.mean(upper_values(rna_dist)) + EPS
    atac_dist /= np.mean(upper_values(atac_dist)) + EPS
    return np.abs(rna_dist - atac_dist)


def sampled_quotient(
    membership: np.ndarray,
    left: np.ndarray,
    right: np.ndarray,
    distances: np.ndarray,
    retained: np.ndarray | None = None,
) -> np.ndarray:
    if retained is not None:
        keep_pairs = retained[left] & retained[right]
        left = left[keep_pairs]
        right = right[keep_pairs]
        distances = distances[keep_pairs]
        state_mass = membership[retained].sum(axis=0) + EPS
        n_cells = int(retained.sum())
    else:
        state_mass = membership.sum(axis=0) + EPS
        n_cells = membership.shape[0]

    if len(distances) == 0:
        raise RuntimeError("No sampled cell pairs remained after perturbation.")

    normalized = distances / (float(np.mean(distances)) + EPS)
    weighted_right = membership[right] * normalized[:, None]
    sampled_sum = membership[left].T @ weighted_right

    # Uniform ordered-pair sampling estimates the full numerator. The constant
    # n_cells^2 / n_samples is needed because the quotient denominator uses
    # full fuzzy-state masses rather than sample masses.
    numerator = sampled_sum * (float(n_cells * n_cells) / len(distances))
    denominator = state_mass[:, None] * state_mass[None, :]
    return numerator / denominator


def configure_style() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans"],
            "font.size": 7,
            "axes.titlesize": 8,
            "axes.labelsize": 7,
            "axes.linewidth": 0.7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )


def plot_results(results: pd.DataFrame, out_dir: Path, top_k: int) -> None:
    configure_style()
    methods = ["Quotient residual", "Centroid baseline"]
    colors = {"Quotient residual": "#3C78A8", "Centroid baseline": "#9A9A9A"}
    fractions = sorted(results["removed_fraction"].unique())
    fig, axes = plt.subplots(1, 3, figsize=(8.4, 2.65))

    metrics = [
        ("spearman_vs_unperturbed", "Residual-matrix correlation", "Spearman correlation"),
        (f"top{top_k}_jaccard", f"Top-{top_k} pair stability", "Jaccard index"),
        ("case_pair_rank", "State 4-state 10 rank", "Residual rank"),
    ]
    for ax, (metric, title, ylabel) in zip(axes, metrics):
        for method in methods:
            means = []
            stds = []
            for fraction in fractions:
                values = results.loc[
                    (results["method"] == method)
                    & (results["removed_fraction"] == fraction),
                    metric,
                ].to_numpy(dtype=float)
                means.append(np.mean(values))
                stds.append(np.std(values, ddof=1))
            ax.errorbar(
                np.asarray(fractions) * 100,
                means,
                yerr=stds,
                marker="o",
                markersize=4,
                linewidth=1.2,
                capsize=2.2,
                label=method,
                color=colors[method],
            )
        ax.set_xlabel("Cells removed (%)")
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.set_xticks(np.asarray(fractions) * 100)
        ax.grid(axis="y", color="#E3E3E3", linewidth=0.55)
    axes[2].invert_yaxis()
    axes[0].legend(loc="lower left")

    for label, ax in zip(("a", "b", "c"), axes):
        ax.text(
            -0.17,
            1.08,
            label,
            transform=ax.transAxes,
            fontsize=9,
            fontweight="bold",
            va="top",
        )
    fig.tight_layout(w_pad=1.6)
    for suffix, kwargs in (
        ("png", {"dpi": 500}),
        ("tiff", {"dpi": 600}),
        ("pdf", {}),
        ("svg", {}),
    ):
        fig.savefig(
            out_dir / f"cell_removal_perturbation_stability.{suffix}",
            bbox_inches="tight",
            **kwargs,
        )
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed-dir", default="outputs/fqalign_10seeds/seed8")
    parser.add_argument(
        "--rna-embedding", default="outputs/baselines/RNA_PCA_embedding.npy"
    )
    parser.add_argument(
        "--atac-embedding", default="outputs/baselines/ATAC_LSI_embedding.npy"
    )
    parser.add_argument("--removed-fractions", nargs="+", type=float, default=[0.05, 0.10])
    parser.add_argument("--repeats", type=int, default=30)
    parser.add_argument("--pair-samples", type=int, default=300000)
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--case-pair", nargs=2, type=int, default=[4, 10])
    parser.add_argument("--seed", type=int, default=20260624)
    parser.add_argument(
        "--out-dir", default="outputs/cell_removal_perturbation_seed8"
    )
    args = parser.parse_args()

    seed_dir = Path(args.seed_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    membership = np.load(seed_dir / "fqalign_membership.npy").astype(np.float64)
    rna = np.load(args.rna_embedding).astype(np.float64)
    atac = np.load(args.atac_embedding).astype(np.float64)
    exact_q_rna = np.load(seed_dir / "quotient_distance_rna.npy")
    exact_q_atac = np.load(seed_dir / "quotient_distance_atac.npy")
    exact_residual = np.abs(exact_q_rna - exact_q_atac)

    if not (len(membership) == len(rna) == len(atac)):
        raise ValueError("Cell counts do not match across inputs.")

    full_centroid_residual = fuzzy_centroid_residual(rna, atac, membership)
    rng = np.random.default_rng(args.seed)
    rows = []
    approximation_rows = []
    n_cells = len(membership)
    case_pair = tuple(sorted(args.case_pair))

    for repeat in range(args.repeats):
        left = rng.integers(0, n_cells, size=args.pair_samples, dtype=np.int32)
        right = rng.integers(0, n_cells, size=args.pair_samples, dtype=np.int32)
        rna_dist = np.linalg.norm(rna[left] - rna[right], axis=1)
        atac_dist = np.linalg.norm(atac[left] - atac[right], axis=1)

        base_q_rna = sampled_quotient(membership, left, right, rna_dist)
        base_q_atac = sampled_quotient(membership, left, right, atac_dist)
        base_q_residual = np.abs(base_q_rna - base_q_atac)

        approximation_rows.append(
            {
                "repeat": repeat,
                "q_rna_spearman_vs_saved": spearmanr(
                    upper_values(base_q_rna), upper_values(exact_q_rna)
                ).statistic,
                "q_atac_spearman_vs_saved": spearmanr(
                    upper_values(base_q_atac), upper_values(exact_q_atac)
                ).statistic,
                "residual_spearman_vs_saved": spearmanr(
                    upper_values(base_q_residual), upper_values(exact_residual)
                ).statistic,
                f"residual_top{args.top_k}_jaccard_vs_saved": jaccard(
                    pair_set(base_q_residual, args.top_k),
                    pair_set(exact_residual, args.top_k),
                ),
            }
        )

        for removed_fraction in args.removed_fractions:
            retained = rng.random(n_cells) >= removed_fraction
            pert_q_rna = sampled_quotient(
                membership, left, right, rna_dist, retained=retained
            )
            pert_q_atac = sampled_quotient(
                membership, left, right, atac_dist, retained=retained
            )
            pert_q_residual = np.abs(pert_q_rna - pert_q_atac)

            pert_centroid_residual = fuzzy_centroid_residual(
                rna[retained], atac[retained], membership[retained]
            )

            rows.append(
                {
                    "repeat": repeat,
                    "removed_fraction": removed_fraction,
                    "retained_cells": int(retained.sum()),
                    "method": "Quotient residual",
                    "spearman_vs_unperturbed": spearmanr(
                        upper_values(base_q_residual),
                        upper_values(pert_q_residual),
                    ).statistic,
                    f"top{args.top_k}_jaccard": jaccard(
                        pair_set(base_q_residual, args.top_k),
                        pair_set(pert_q_residual, args.top_k),
                    ),
                    "case_pair_rank": pair_rank(pert_q_residual, case_pair),
                    "case_pair_value": float(
                        pert_q_residual[case_pair[0], case_pair[1]]
                    ),
                }
            )
            rows.append(
                {
                    "repeat": repeat,
                    "removed_fraction": removed_fraction,
                    "retained_cells": int(retained.sum()),
                    "method": "Centroid baseline",
                    "spearman_vs_unperturbed": spearmanr(
                        upper_values(full_centroid_residual),
                        upper_values(pert_centroid_residual),
                    ).statistic,
                    f"top{args.top_k}_jaccard": jaccard(
                        pair_set(full_centroid_residual, args.top_k),
                        pair_set(pert_centroid_residual, args.top_k),
                    ),
                    "case_pair_rank": pair_rank(
                        pert_centroid_residual, case_pair
                    ),
                    "case_pair_value": float(
                        pert_centroid_residual[case_pair[0], case_pair[1]]
                    ),
                }
            )

    results = pd.DataFrame(rows)
    approximation = pd.DataFrame(approximation_rows)
    results.to_csv(out_dir / "cell_removal_perturbation_results.csv", index=False)
    approximation.to_csv(
        out_dir / "quotient_monte_carlo_quality_control.csv", index=False
    )

    summary = (
        results.groupby(["method", "removed_fraction"])
        .agg(
            n_repeats=("repeat", "count"),
            spearman_mean=("spearman_vs_unperturbed", "mean"),
            spearman_sd=("spearman_vs_unperturbed", "std"),
            topk_jaccard_mean=(f"top{args.top_k}_jaccard", "mean"),
            topk_jaccard_sd=(f"top{args.top_k}_jaccard", "std"),
            case_pair_rank_mean=("case_pair_rank", "mean"),
            case_pair_rank_sd=("case_pair_rank", "std"),
            case_pair_value_mean=("case_pair_value", "mean"),
            case_pair_value_sd=("case_pair_value", "std"),
        )
        .reset_index()
    )
    summary.to_csv(out_dir / "cell_removal_perturbation_summary.csv", index=False)

    qc_summary = {
        "repeats": args.repeats,
        "pair_samples_per_repeat": args.pair_samples,
        "mean_q_rna_spearman_vs_saved": float(
            approximation["q_rna_spearman_vs_saved"].mean()
        ),
        "mean_q_atac_spearman_vs_saved": float(
            approximation["q_atac_spearman_vs_saved"].mean()
        ),
        "mean_residual_spearman_vs_saved": float(
            approximation["residual_spearman_vs_saved"].mean()
        ),
        f"mean_residual_top{args.top_k}_jaccard_vs_saved": float(
            approximation[
                f"residual_top{args.top_k}_jaccard_vs_saved"
            ].mean()
        ),
    }
    (out_dir / "perturbation_metadata.json").write_text(
        json.dumps(qc_summary, indent=2), encoding="utf-8"
    )
    plot_results(results, out_dir, args.top_k)

    print(summary.to_string(index=False))
    print(json.dumps(qc_summary, indent=2))
    print(f"Wrote results to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
