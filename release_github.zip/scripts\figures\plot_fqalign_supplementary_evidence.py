#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats


sns.set_theme(style="whitegrid", context="paper")


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def savefig(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    plt.tight_layout()
    plt.savefig(path, dpi=300, bbox_inches="tight")
    plt.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    plt.close()


def p_stars(p):
    if pd.isna(p):
        return ""
    if p < 1e-4:
        return "****"
    if p < 1e-3:
        return "***"
    if p < 1e-2:
        return "**"
    if p < 0.05:
        return "*"
    return "ns"


def plot_reliability_qc_heatmap(evidence_dir, out_dir):
    path = Path(evidence_dir) / "TableS_reliability_qc_correlations.csv"

    if not path.exists():
        print(f"[skip] Missing {path}")
        return

    df = pd.read_csv(path)

    if df.empty:
        print("[skip] Empty reliability-QC correlation table")
        return

    value = df.pivot(
        index="weight",
        columns="qc_metric",
        values="spearman_r"
    )

    pvals = df.pivot(
        index="weight",
        columns="qc_metric",
        values="spearman_p"
    )

    # -----------------------------------
    # annotation
    # -----------------------------------
    annot = value.copy().astype(str)

    for i in value.index:
        for j in value.columns:
            r = value.loc[i, j]
            p = pvals.loc[i, j]

            annot.loc[i, j] = f"{r:.2f}\n{p_stars(p)}"

    # -----------------------------------
    # figure
    # -----------------------------------
    plt.figure(
        figsize=(1.25 * len(value.columns) + 2.8, 3.8)
    )

    ax = sns.heatmap(
        value,
        cmap="vlag",
        center=0,
        vmin=-1,
        vmax=1,

        annot=annot,
        fmt="",

        annot_kws={
            "fontsize": 9
        },

        linewidths=0.6,
        linecolor="white",

        square=False,

        cbar_kws={
            "label": "Spearman correlation"
        }
    )

    # -----------------------------------
    # labels
    # -----------------------------------
    ax.set_xlabel(
        "QC metric",
        fontsize=13,
        labelpad=10
    )

    ax.set_ylabel(
        "Modality weight",
        fontsize=13,
        labelpad=12
    )

    ax.set_title(
        "Reliability–QC association",
        fontsize=16,
        pad=14,
        weight="bold"
    )

    # -----------------------------------
    # tick style
    # -----------------------------------
    plt.xticks(
        rotation=35,
        ha="right",
        fontsize=10
    )

    plt.yticks(
        rotation=0,
        fontsize=10
    )

    # -----------------------------------
    # colorbar
    # -----------------------------------
    cbar = ax.collections[0].colorbar
    cbar.ax.tick_params(labelsize=10)
    cbar.set_label(
        "Spearman correlation",
        fontsize=11
    )

    # -----------------------------------
    # layout
    # -----------------------------------
    plt.tight_layout()

    savefig(
        Path(out_dir) /
        "FigureS_reliability_qc_correlation_heatmap.png"
    )

    plt.close()


def pick_existing_pairs(cell_df):
    candidates = [
        ("rna weight", "detected genes"),
        ("rna weight", "rna counts"),
        ("atac weight", "detected peaks"),
        ("atac weight", "atac counts"),
        ("atac weight", "atac enrichment"),
        ("atac weight", "atac frip"),
    ]
    return [(x, y) for x, y in candidates if x in cell_df.columns and y in cell_df.columns]


def plot_reliability_qc_scatter(evidence_dir, out_dir):
    path = Path(evidence_dir) / "TableS_fqalign_cell_level_evidence.csv"
    if not path.exists():
        print(f"[skip] Missing {path}")
        return

    df = pd.read_csv(path)
    pairs = pick_existing_pairs(df)
    if not pairs:
        print("[skip] No QC columns available for scatter plots")
        return

    n = len(pairs)
    ncols = min(3, n)
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(4.0 * ncols, 3.3 * nrows))
    axes = np.atleast_1d(axes).ravel()

    for ax, (x, y) in zip(axes, pairs):
        sub = df[[x, y]].replace([np.inf, -np.inf], np.nan).dropna()
        if len(sub) < 10:
            ax.axis("off")
            continue

        rho, p = stats.spearmanr(sub[x], sub[y])
        hb = ax.hexbin(sub[x], sub[y], gridsize=45, mincnt=1, cmap="viridis")
        ax.set_xlabel(x)
        ax.set_ylabel(y)
        ax.set_title(f"Spearman rho={rho:.2f}, P={p:.1e}")
        fig.colorbar(hb, ax=ax, label="Cell count")

    for ax in axes[len(pairs):]:
        ax.axis("off")

    savefig(Path(out_dir) / "FigureS_reliability_qc_scatter.png")


def load_quotient_matrices(result_dir, evidence_dir):
    result_dir = Path(result_dir)
    evidence_dir = Path(evidence_dir)

    q_rna_path = result_dir / "quotient_distance_rna.npy"
    q_atac_path = result_dir / "quotient_distance_atac.npy"

    if not q_rna_path.exists() or not q_atac_path.exists():
        print("[skip] Missing quotient_distance_rna.npy or quotient_distance_atac.npy")
        return None, None, None

    q_rna = np.load(q_rna_path)
    q_atac = np.load(q_atac_path)

    residual_path = evidence_dir / "quotient_alignment_residual.npy"
    residual = np.load(residual_path) if residual_path.exists() else np.abs(q_rna - q_atac)

    return q_rna, q_atac, residual


def plot_quotient_topology(result_dir, evidence_dir, out_dir):
    q_rna, q_atac, residual = load_quotient_matrices(result_dir, evidence_dir)
    if q_rna is None:
        return

    k = q_rna.shape[0]
    mask = ~np.eye(k, dtype=bool)
    x = q_rna[mask].ravel()
    y = q_atac[mask].ravel()

    pear = stats.pearsonr(x, y)
    spear = stats.spearmanr(x, y)

    fig, axes = plt.subplots(1, 2, figsize=(9.2, 3.8))

    ax = axes[0]
    ax.scatter(x, y, s=28, alpha=0.75, edgecolor="none")
    lim_min = min(x.min(), y.min())
    lim_max = max(x.max(), y.max())
    ax.plot([lim_min, lim_max], [lim_min, lim_max], color="black", lw=1, ls="--")
    ax.set_xlabel("RNA quotient distance")
    ax.set_ylabel("ATAC quotient distance")
    ax.set_title(
        f"State-level topology consistency\n"
        f"Pearson r={pear.statistic:.2f}, Spearman rho={spear.statistic:.2f}"
    )

    ax = axes[1]
    sns.heatmap(
        residual,
        cmap="magma",
        square=True,
        ax=ax,
        cbar_kws={"label": "|RNA - ATAC|"},
    )
    ax.set_xlabel("Fuzzy state")
    ax.set_ylabel("Fuzzy state")
    ax.set_title("Quotient alignment residual")

    savefig(Path(out_dir) / "FigureS_quotient_topology_consistency.png")


def plot_quotient_residual_summary(evidence_dir, out_dir):
    path = Path(evidence_dir) / "TableS_quotient_topology_metrics.csv"
    if not path.exists():
        return

    df = pd.read_csv(path)
    metrics = [
        "mean_abs_residual",
        "median_abs_residual",
        "frobenius_residual",
        "pearson_topology_r",
        "spearman_topology_r",
    ]
    metrics = [m for m in metrics if m in df.columns]
    if not metrics:
        return

    plot_df = df[metrics].T.reset_index()
    plot_df.columns = ["metric", "value"]

    plt.figure(figsize=(5.8, 3.6))
    ax = sns.barplot(data=plot_df, x="metric", y="value", color="#4C78A8")
    ax.set_xlabel("")
    ax.set_ylabel("Value")
    ax.set_title("Quotient topology summary")
    plt.xticks(rotation=35, ha="right")
    savefig(Path(out_dir) / "FigureS_quotient_topology_metrics_barplot.png")


def plot_boundary_enrichment(evidence_dir, out_dir):
    per_cell_path = Path(evidence_dir) / "TableS_low_membership_boundary_per_cell.csv"
    summary_path = Path(evidence_dir) / "TableS_low_membership_boundary_enrichment.csv"

    if not per_cell_path.exists():
        print(f"[skip] Missing {per_cell_path}")
        return

    df = pd.read_csv(per_cell_path)
    df["group"] = np.where(df["is_low_membership"], "Low membership", "Other cells")

    p_text = ""
    if summary_path.exists():
        s = pd.read_csv(summary_path).iloc[0]
        if "permutation_p" in s:
            p_text = f"Permutation P={s['permutation_p']:.2e}"

    plt.figure(figsize=(4.5, 3.8))
    ax = sns.violinplot(
        data=df,
        x="group",
        y="boundary_neighbor_fraction",
        inner=None,
        cut=0,
        palette=["#E45756", "#A0A0A0"],
    )
    sns.boxplot(
        data=df,
        x="group",
        y="boundary_neighbor_fraction",
        width=0.22,
        showcaps=True,
        boxprops={"facecolor": "white", "edgecolor": "black"},
        medianprops={"color": "black"},
        whiskerprops={"color": "black"},
        ax=ax,
    )
    ax.set_xlabel("")
    ax.set_ylabel("Boundary neighbor fraction")
    ax.set_title(f"Low-membership boundary enrichment\n{p_text}".strip())
    savefig(Path(out_dir) / "FigureS_low_membership_boundary_enrichment.png")


def plot_low_membership_umap(result_dir, evidence_dir, out_dir):
    result_dir = Path(result_dir)
    evidence_dir = Path(evidence_dir)

    emb_path = result_dir / "fqalign_embedding.npy"
    if not emb_path.exists():
        emb_path = result_dir / "FuzzyQuotientAlign_embedding.npy"
    per_cell_path = evidence_dir / "TableS_low_membership_boundary_per_cell.csv"

    if not emb_path.exists() or not per_cell_path.exists():
        print("[skip] Missing embedding or boundary per-cell table")
        return

    emb = np.load(emb_path)
    df = pd.read_csv(per_cell_path)

    if emb.shape[1] < 2:
        print("[skip] Embedding has fewer than 2 dimensions")
        return

    low = df["is_low_membership"].to_numpy().astype(bool)

    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.6))

    ax = axes[0]
    ax.scatter(emb[:, 0], emb[:, 1], s=2, c="#D0D0D0", alpha=0.45, rasterized=True)
    ax.scatter(emb[low, 0], emb[low, 1], s=5, c="#D62728", alpha=0.9, rasterized=True)
    ax.set_title("Low-membership cells")
    ax.set_xlabel("Embedding 1")
    ax.set_ylabel("Embedding 2")

    ax = axes[1]
    sc = ax.scatter(
        emb[:, 0],
        emb[:, 1],
        s=3,
        c=df["boundary_neighbor_fraction"],
        cmap="viridis",
        alpha=0.85,
        rasterized=True,
    )
    ax.set_title("Boundary neighbor fraction")
    ax.set_xlabel("Embedding 1")
    ax.set_ylabel("Embedding 2")
    fig.colorbar(sc, ax=ax, label="Boundary fraction")

    savefig(Path(out_dir) / "FigureS_low_membership_boundary_umap.png")


def plot_state_marker_dotplot(evidence_dir, out_dir, top_n_per_state=5):
    marker_path = Path(evidence_dir) / "TableS_state_marker_genes_wilcoxon.csv"
    if not marker_path.exists():
        print(f"[skip] Missing {marker_path}")
        return

    df = pd.read_csv(marker_path)
    if df.empty:
        return

    # scanpy rank_genes_groups df columns usually include group, names, scores,
    # logfoldchanges, pvals, pvals_adj.
    required = {"group", "names"}
    if not required.issubset(set(df.columns)):
        print("[skip] Marker table lacks group/names columns")
        return

    score_col = "logfoldchanges" if "logfoldchanges" in df.columns else "scores"
    p_col = "pvals_adj" if "pvals_adj" in df.columns else "pvals"

    top = (
        df.sort_values(["group", score_col], ascending=[True, False])
        .groupby("group")
        .head(top_n_per_state)
        .copy()
    )
    top["gene"] = top["names"].astype(str)
    top["state"] = top["group"].astype(str)
    top["minus_log10_p"] = -np.log10(top[p_col].clip(lower=1e-300)) if p_col in top else 1.0

    # Keep the plot readable.
    genes = top["gene"].drop_duplicates().tolist()
    if len(genes) > 60:
        genes = genes[:60]
        top = top[top["gene"].isin(genes)]

    plt.figure(figsize=(max(8, 0.25 * len(genes)), max(4, 0.32 * top["state"].nunique())))
    ax = sns.scatterplot(
        data=top,
        x="gene",
        y="state",
        size="minus_log10_p",
        hue=score_col,
        palette="RdBu_r",
        sizes=(30, 180),
        edgecolor="black",
        linewidth=0.25,
    )
    ax.set_xlabel("Marker gene")
    ax.set_ylabel("Fuzzy state")
    ax.set_title("Top marker genes per fuzzy state")
    plt.xticks(rotation=60, ha="right")
    plt.legend(bbox_to_anchor=(1.02, 1), loc="upper left", frameon=False)
    savefig(Path(out_dir) / "FigureS_state_marker_dotplot.png")


def plot_state_summary(evidence_dir, out_dir):
    path = Path(evidence_dir) / "TableS_state_summary.csv"
    if not path.exists():
        return

    df = pd.read_csv(path)
    if df.empty:
        return

    fig, axes = plt.subplots(1, 2, figsize=(8.2, 3.6))

    sns.barplot(data=df, x="state", y="mean_max_membership", color="#59A14F", ax=axes[0])
    axes[0].set_xlabel("Fuzzy state")
    axes[0].set_ylabel("Mean max membership")
    axes[0].set_title("State assignment confidence")

    sns.barplot(data=df, x="state", y="dominant_celltype_fraction", color="#4C78A8", ax=axes[1])
    axes[1].set_xlabel("Fuzzy state")
    axes[1].set_ylabel("Dominant cell-type fraction")
    axes[1].set_title("State-celltype dominance")

    savefig(Path(out_dir) / "FigureS_state_summary.png")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--result-dir", required=True, help="例如 /iei4/scCFMD/fqalign_10seeds/seed8")
    parser.add_argument("--evidence-dir", required=True, help="上一脚本输出的 supplementary_evidence 目录")
    parser.add_argument("--out-dir", required=True, help="图片输出目录")
    parser.add_argument("--top-n-per-state", type=int, default=5)
    args = parser.parse_args()

    ensure_dir(args.out_dir)

    plot_reliability_qc_heatmap(args.evidence_dir, args.out_dir)
    plot_reliability_qc_scatter(args.evidence_dir, args.out_dir)

    plot_quotient_topology(args.result_dir, args.evidence_dir, args.out_dir)
    plot_quotient_residual_summary(args.evidence_dir, args.out_dir)

    plot_boundary_enrichment(args.evidence_dir, args.out_dir)
    plot_low_membership_umap(args.result_dir, args.evidence_dir, args.out_dir)

    plot_state_marker_dotplot(args.evidence_dir, args.out_dir, args.top_n_per_state)
    plot_state_summary(args.evidence_dir, args.out_dir)

    print(f"[OK] Figures written to: {args.out_dir}")


if __name__ == "__main__":
    main()