#!/usr/bin/env python3
"""Post-hoc validation of FQ-Align quotient residuals.

This script uses saved FQ-Align outputs and does not retrain the model.
It computes:
1. Residual stability across training seeds after fuzzy-state alignment.
2. A fuzzy-centroid distance-discrepancy baseline.
3. Top residual-pair summaries for supplementary reporting.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from scipy.optimize import linear_sum_assignment
from scipy.spatial.distance import cdist
from scipy.stats import pearsonr, spearmanr


EPS = 1e-12


def upper_values(matrix: np.ndarray) -> np.ndarray:
    return matrix[np.triu_indices(matrix.shape[0], k=1)]


def normalize_offdiag_mean(matrix: np.ndarray) -> np.ndarray:
    values = upper_values(matrix)
    return matrix / (float(np.mean(values)) + EPS)


def residual_matrix(q_rna: np.ndarray, q_atac: np.ndarray) -> np.ndarray:
    return np.abs(np.asarray(q_rna, float) - np.asarray(q_atac, float))


def align_states(reference_u: np.ndarray, other_u: np.ndarray) -> np.ndarray:
    """Return other-state indices ordered to match reference-state indices.

    States are matched by maximizing Pearson correlation between membership
    columns across the same cells. Absolute correlation is deliberately not
    used because inverted memberships do not represent the same fuzzy state.
    """
    if reference_u.shape != other_u.shape:
        raise ValueError(
            f"Membership shape mismatch: {reference_u.shape} vs {other_u.shape}"
        )
    k = reference_u.shape[1]
    corr = np.empty((k, k), dtype=float)
    for i in range(k):
        x = reference_u[:, i]
        for j in range(k):
            y = other_u[:, j]
            if np.std(x) < EPS or np.std(y) < EPS:
                corr[i, j] = -1.0
            else:
                corr[i, j] = np.corrcoef(x, y)[0, 1]
    ref_idx, other_idx = linear_sum_assignment(-corr)
    order = np.empty(k, dtype=int)
    order[ref_idx] = other_idx
    return order


def reorder_square(matrix: np.ndarray, order: np.ndarray) -> np.ndarray:
    return np.asarray(matrix)[np.ix_(order, order)]


def fuzzy_centroid_distances(x: np.ndarray, membership: np.ndarray) -> np.ndarray:
    mass = membership.sum(axis=0) + EPS
    centroids = membership.T @ x / mass[:, None]
    distances = cdist(centroids, centroids, metric="euclidean")
    return normalize_offdiag_mean(distances)


def ranked_pairs(matrix: np.ndarray) -> list[tuple[int, int, float]]:
    rows = [
        (i, j, float(matrix[i, j]))
        for i, j in combinations(range(matrix.shape[0]), 2)
    ]
    return sorted(rows, key=lambda row: row[2], reverse=True)


def pair_set(rows: list[tuple[int, int, float]], top_k: int) -> set[tuple[int, int]]:
    return {(i, j) for i, j, _ in rows[:top_k]}


def jaccard(a: set, b: set) -> float:
    return len(a & b) / max(len(a | b), 1)


def load_seed(seed_dir: Path) -> dict:
    required = {
        "membership": seed_dir / "fqalign_membership.npy",
        "q_rna": seed_dir / "quotient_distance_rna.npy",
        "q_atac": seed_dir / "quotient_distance_atac.npy",
    }
    missing = [str(path) for path in required.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"{seed_dir}: missing {missing}")
    return {
        "membership": np.load(required["membership"]),
        "q_rna": np.load(required["q_rna"]),
        "q_atac": np.load(required["q_atac"]),
    }


def plot_validation(
    stability_df: pd.DataFrame,
    pair_df: pd.DataFrame,
    aligned_residuals: dict[str, np.ndarray],
    aligned_centroid_residuals: dict[str, np.ndarray],
    reference_seed: str,
    case_pair: tuple[int, int],
    top_k: int,
    out_dir: Path,
) -> None:
    other = stability_df[stability_df["seed"] != reference_seed].copy()
    case_i, case_j = case_pair
    case_row = pair_df[
        (pair_df["state_i"] == case_i) & (pair_df["state_j"] == case_j)
    ]
    if case_row.empty:
        raise ValueError(f"Case pair {case_i}-{case_j} was not found.")

    seed_names = list(aligned_residuals)
    case_values = [
        float(aligned_residuals[name][case_i, case_j]) for name in seed_names
    ]
    q_values = upper_values(aligned_residuals[reference_seed])
    c_values = upper_values(aligned_centroid_residuals[reference_seed])
    rho = spearmanr(q_values, c_values).statistic

    plt.rcParams.update(
        {
            "font.family": "Arial",
            "font.size": 9,
            "axes.linewidth": 0.8,
            "xtick.major.width": 0.8,
            "ytick.major.width": 0.8,
        }
    )
    fig, axes = plt.subplots(1, 3, figsize=(10.2, 3.05))

    ax = axes[0]
    x = np.arange(len(other))
    ax.scatter(
        x,
        other["quotient_spearman_vs_reference"],
        s=30,
        color="#377eb8",
        edgecolor="white",
        linewidth=0.5,
        zorder=3,
    )
    ax.axhline(
        other["quotient_spearman_vs_reference"].mean(),
        color="#d95f02",
        linewidth=1.2,
        linestyle="--",
    )
    ax.set_xticks(x, other["seed"], rotation=45, ha="right")
    ax.set_ylim(0.85, 1.005)
    ax.set_ylabel("Spearman correlation")
    ax.set_title("Residual-matrix stability")
    ax.grid(axis="y", color="#dddddd", linewidth=0.6)

    ax = axes[1]
    x = np.arange(len(seed_names))
    colors = ["#d95f02" if name == reference_seed else "#4daf4a" for name in seed_names]
    ax.scatter(x, case_values, s=32, color=colors, edgecolor="white", linewidth=0.5)
    ax.axhline(np.mean(case_values), color="#333333", linewidth=1.1, linestyle="--")
    ax.set_xticks(x, seed_names, rotation=45, ha="right")
    ax.set_ylabel("Quotient residual")
    ax.set_title(f"State {case_i}-{case_j} across seeds")
    ax.grid(axis="y", color="#dddddd", linewidth=0.6)

    ax = axes[2]
    ax.scatter(
        c_values,
        q_values,
        s=22,
        color="#777777",
        alpha=0.8,
        edgecolor="white",
        linewidth=0.35,
    )
    ax.set_xlabel("Centroid-distance residual")
    ax.set_ylabel("Quotient residual")
    ax.set_title(f"Quotient vs centroid baseline\nSpearman rho = {rho:.2f}")
    ax.grid(color="#dddddd", linewidth=0.6)

    for label, ax in zip(("a", "b", "c"), axes):
        ax.text(
            -0.16,
            1.08,
            label,
            transform=ax.transAxes,
            fontsize=11,
            fontweight="bold",
            va="top",
        )
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)

    fig.tight_layout(w_pad=2.0)
    fig.savefig(out_dir / "residual_validation_panels.png", dpi=400, bbox_inches="tight")
    fig.savefig(out_dir / "residual_validation_panels.pdf", bbox_inches="tight")
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--seed-root",
        default="outputs/fqalign_10seeds",
        help="Directory containing seed0, seed1, ... subdirectories.",
    )
    parser.add_argument(
        "--rna-embedding",
        default="outputs/baselines/RNA_PCA_embedding.npy",
    )
    parser.add_argument(
        "--atac-embedding",
        default="outputs/baselines/ATAC_LSI_embedding.npy",
    )
    parser.add_argument("--reference-seed", default="seed0")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--top-pairs", type=int, default=3)
    parser.add_argument(
        "--case-pair",
        nargs=2,
        type=int,
        default=(7, 8),
        metavar=("STATE_I", "STATE_J"),
        help="Representative state pair shown in the stability panel.",
    )
    parser.add_argument(
        "--out-dir",
        default="outputs/residual_validation",
    )
    args = parser.parse_args()

    seed_root = Path(args.seed_root)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    seed_dirs = sorted(
        [path for path in seed_root.iterdir() if path.is_dir() and path.name.startswith("seed")],
        key=lambda path: int(path.name.replace("seed", "")),
    )
    if len(seed_dirs) < 2:
        raise RuntimeError(f"Need at least two seed directories under {seed_root}")

    rna_x = np.load(args.rna_embedding)
    atac_x = np.load(args.atac_embedding)
    seeds = {path.name: load_seed(path) for path in seed_dirs}
    reference = seeds[args.reference_seed]
    ref_u = reference["membership"]

    if rna_x.shape[0] != ref_u.shape[0] or atac_x.shape[0] != ref_u.shape[0]:
        raise ValueError(
            "Cell count mismatch among RNA, ATAC, and membership arrays: "
            f"{rna_x.shape}, {atac_x.shape}, {ref_u.shape}"
        )

    # Reference residuals and rankings.
    ref_residual = residual_matrix(reference["q_rna"], reference["q_atac"])
    ref_ranking = ranked_pairs(ref_residual)
    ref_centroid_rna = fuzzy_centroid_distances(rna_x, ref_u)
    ref_centroid_atac = fuzzy_centroid_distances(atac_x, ref_u)
    ref_centroid_residual = residual_matrix(ref_centroid_rna, ref_centroid_atac)
    ref_centroid_ranking = ranked_pairs(ref_centroid_residual)

    stability_rows = []
    aligned_residuals = {}
    aligned_centroid_residuals = {}
    mappings = {}

    for seed_name, payload in seeds.items():
        order = (
            np.arange(ref_u.shape[1])
            if seed_name == args.reference_seed
            else align_states(ref_u, payload["membership"])
        )
        mappings[seed_name] = order.tolist()
        q_rna = reorder_square(payload["q_rna"], order)
        q_atac = reorder_square(payload["q_atac"], order)
        residual = residual_matrix(q_rna, q_atac)
        aligned_residuals[seed_name] = residual

        aligned_u = payload["membership"][:, order]
        centroid_rna = fuzzy_centroid_distances(rna_x, aligned_u)
        centroid_atac = fuzzy_centroid_distances(atac_x, aligned_u)
        centroid_res = residual_matrix(centroid_rna, centroid_atac)
        aligned_centroid_residuals[seed_name] = centroid_res

        quotient_vals = upper_values(residual)
        ref_vals = upper_values(ref_residual)
        centroid_vals = upper_values(centroid_res)
        q_rank = ranked_pairs(residual)
        c_rank = ranked_pairs(centroid_res)

        stability_rows.append(
            {
                "seed": seed_name,
                "quotient_pearson_vs_reference": pearsonr(ref_vals, quotient_vals).statistic,
                "quotient_spearman_vs_reference": spearmanr(ref_vals, quotient_vals).statistic,
                f"quotient_top{args.top_k}_jaccard_vs_reference": jaccard(
                    pair_set(ref_ranking, args.top_k),
                    pair_set(q_rank, args.top_k),
                ),
                "centroid_pearson_vs_reference": pearsonr(
                    upper_values(ref_centroid_residual), centroid_vals
                ).statistic,
                "centroid_spearman_vs_reference": spearmanr(
                    upper_values(ref_centroid_residual), centroid_vals
                ).statistic,
                f"centroid_top{args.top_k}_jaccard_vs_reference": jaccard(
                    pair_set(ref_centroid_ranking, args.top_k),
                    pair_set(c_rank, args.top_k),
                ),
                "quotient_vs_centroid_pearson": pearsonr(
                    quotient_vals, centroid_vals
                ).statistic,
                "quotient_vs_centroid_spearman": spearmanr(
                    quotient_vals, centroid_vals
                ).statistic,
                "quotient_mean_residual": float(np.mean(quotient_vals)),
                "centroid_mean_residual": float(np.mean(centroid_vals)),
            }
        )

    stability_df = pd.DataFrame(stability_rows)
    stability_df.to_csv(out_dir / "residual_stability_by_seed.csv", index=False)

    # Pair-level stability across seeds in the reference state numbering.
    pair_rows = []
    for i, j in combinations(range(ref_u.shape[1]), 2):
        q_values = np.array([m[i, j] for m in aligned_residuals.values()])
        c_values = np.array([m[i, j] for m in aligned_centroid_residuals.values()])
        q_ranks = []
        for matrix in aligned_residuals.values():
            rank_map = {
                (a, b): rank + 1
                for rank, (a, b, _) in enumerate(ranked_pairs(matrix))
            }
            q_ranks.append(rank_map[(i, j)])
        pair_rows.append(
            {
                "state_i": i,
                "state_j": j,
                "reference_quotient_residual": float(ref_residual[i, j]),
                "quotient_mean_across_seeds": float(np.mean(q_values)),
                "quotient_sd_across_seeds": float(np.std(q_values, ddof=1)),
                "quotient_cv_across_seeds": float(
                    np.std(q_values, ddof=1) / (np.mean(q_values) + EPS)
                ),
                "quotient_mean_rank": float(np.mean(q_ranks)),
                f"quotient_top{args.top_k}_frequency": float(
                    np.mean(np.asarray(q_ranks) <= args.top_k)
                ),
                "reference_centroid_residual": float(ref_centroid_residual[i, j]),
                "centroid_mean_across_seeds": float(np.mean(c_values)),
                "centroid_sd_across_seeds": float(np.std(c_values, ddof=1)),
            }
        )
    pair_df = pd.DataFrame(pair_rows).sort_values(
        "reference_quotient_residual", ascending=False
    )
    pair_df.to_csv(out_dir / "residual_pair_stability.csv", index=False)

    # Supplementary top-pair summary from the reference seed. Cell-type
    # annotations are intentionally excluded because state numbering may be
    # remapped during final biological curation.
    top_rows = []
    for rank, (i, j, value) in enumerate(ref_ranking[: args.top_pairs], start=1):
        pair_stability = pair_df[
            (pair_df["state_i"] == i) & (pair_df["state_j"] == j)
        ].iloc[0]
        top_rows.append(
            {
                "rank": rank,
                "state_i": i,
                "state_j": j,
                "q_rna": float(reference["q_rna"][i, j]),
                "q_atac": float(reference["q_atac"][i, j]),
                "quotient_residual": value,
                "mean_residual_across_seeds": pair_stability[
                    "quotient_mean_across_seeds"
                ],
                "sd_residual_across_seeds": pair_stability[
                    "quotient_sd_across_seeds"
                ],
                "mean_rank_across_seeds": pair_stability["quotient_mean_rank"],
                f"top{args.top_k}_frequency": pair_stability[
                    f"quotient_top{args.top_k}_frequency"
                ],
                "centroid_residual": float(ref_centroid_residual[i, j]),
            }
        )
    pd.DataFrame(top_rows).to_csv(
        out_dir / "top_residual_pairs_supplementary.csv", index=False
    )

    with (out_dir / "state_alignment_mappings.json").open("w", encoding="utf-8") as f:
        json.dump(mappings, f, indent=2)

    summary = {
        "n_seeds": len(seeds),
        "n_cells": int(ref_u.shape[0]),
        "n_states": int(ref_u.shape[1]),
        "mean_quotient_spearman_vs_reference_excluding_reference": float(
            stability_df.loc[
                stability_df["seed"] != args.reference_seed,
                "quotient_spearman_vs_reference",
            ].mean()
        ),
        f"mean_quotient_top{args.top_k}_jaccard_excluding_reference": float(
            stability_df.loc[
                stability_df["seed"] != args.reference_seed,
                f"quotient_top{args.top_k}_jaccard_vs_reference",
            ].mean()
        ),
        "mean_quotient_vs_centroid_spearman": float(
            stability_df["quotient_vs_centroid_spearman"].mean()
        ),
        "reference_quotient_vs_centroid_spearman": float(
            stability_df.loc[
                stability_df["seed"] == args.reference_seed,
                "quotient_vs_centroid_spearman",
            ].iloc[0]
        ),
    }
    with (out_dir / "residual_validation_summary.json").open(
        "w", encoding="utf-8"
    ) as f:
        json.dump(summary, f, indent=2)

    plot_validation(
        stability_df=stability_df,
        pair_df=pair_df,
        aligned_residuals=aligned_residuals,
        aligned_centroid_residuals=aligned_centroid_residuals,
        reference_seed=args.reference_seed,
        case_pair=tuple(args.case_pair),
        top_k=args.top_k,
        out_dir=out_dir,
    )

    print(json.dumps(summary, indent=2))
    print(f"Wrote results to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
