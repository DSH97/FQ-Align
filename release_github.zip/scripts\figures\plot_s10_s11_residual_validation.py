#!/usr/bin/env python3
"""Split residual validation into Supplementary Figures S10 and S11."""

from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
STABILITY = ROOT / "scCFMD" / "outputs" / "residual_validation_seed8_reference"
UTILITY = ROOT / "scCFMD" / "outputs" / "residual_pair_utility_validation"
PERTURB = ROOT / "scCFMD" / "outputs" / "cell_removal_perturbation_seed8_high_precision"
FIGDIR = ROOT / "paper" / "figures"

BLUE = "#3C78A8"
GREY = "#969696"
ORANGE = "#E17C24"
GREEN = "#4E9F50"


def configure() -> None:
    mpl.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "DejaVu Sans"],
            "font.size": 7,
            "axes.titlesize": 8,
            "axes.labelsize": 7,
            "axes.linewidth": 0.7,
            "axes.spines.top": False,
            "axes.spines.right": False,
            "legend.frameon": False,
            "pdf.fonttype": 42,
            "svg.fonttype": "none",
        }
    )


def panel_letters(axes) -> None:
    for label, ax in zip("abcdef", np.ravel(axes)):
        ax.text(
            -0.17,
            1.12,
            f"({label})",
            transform=ax.transAxes,
            fontsize=9.5,
            fontweight="bold",
            va="top",
            ha="left",
            clip_on=False,
        )
        ax.grid(axis="y", color="#E4E4E4", linewidth=0.5)


def save(fig, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(path.with_suffix(".png"), dpi=500, bbox_inches="tight")
    fig.savefig(path.with_suffix(".pdf"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".svg"), bbox_inches="tight")
    fig.savefig(path.with_suffix(".tiff"), dpi=600, bbox_inches="tight")
    plt.close(fig)


def plot_s10() -> None:
    seed = pd.read_csv(STABILITY / "residual_stability_by_seed.csv")
    pairs = pd.read_csv(STABILITY / "residual_pair_stability.csv")
    perturb = pd.read_csv(PERTURB / "cell_removal_perturbation_results.csv")
    sub = seed[seed["seed"] != "seed8"].copy()
    case = pairs[(pairs["state_i"] == 4) & (pairs["state_j"] == 10)].iloc[0]

    fig, axes = plt.subplots(2, 3, figsize=(10.2, 5.3))

    ax = axes[0, 0]
    x = np.arange(len(sub))
    ax.scatter(x, sub["quotient_spearman_vs_reference"], color=BLUE, s=25)
    ax.axhline(
        sub["quotient_spearman_vs_reference"].mean(),
        color=ORANGE,
        linestyle="--",
        linewidth=1,
    )
    ax.set_xticks(x, sub["seed"], rotation=40, ha="right")
    ax.set_ylabel("Spearman correlation")
    ax.set_ylim(0.88, 1.005)
    ax.set_title("Residual-matrix agreement", fontweight="bold", pad=8)

    ax = axes[0, 1]
    ax.scatter(x, sub["quotient_top5_jaccard_vs_reference"], color=BLUE, s=25)
    ax.axhline(
        sub["quotient_top5_jaccard_vs_reference"].mean(),
        color=ORANGE,
        linestyle="--",
        linewidth=1,
    )
    ax.set_xticks(x, sub["seed"], rotation=40, ha="right")
    ax.set_ylabel("Top-5 Jaccard index")
    ax.set_ylim(-0.05, 1.05)
    ax.set_title("Top-5 pair recovery", fontweight="bold", pad=8)

    ax = axes[0, 2]
    ax.errorbar(
        [0],
        [case["quotient_mean_across_seeds"]],
        yerr=[case["quotient_sd_across_seeds"]],
        marker="o",
        color=GREEN,
        capsize=3,
        markersize=5,
    )
    ax.scatter(
        [0],
        [case["reference_quotient_residual"]],
        color=ORANGE,
        s=28,
        zorder=3,
        label="Seed8",
    )
    ax.set_xticks([0], ["State 4-state 10"])
    ax.set_ylabel("Quotient residual")
    ax.set_title("State 4-state 10 residual", fontweight="bold", pad=8)
    ax.legend(loc="lower right")

    fractions = sorted(perturb["removed_fraction"].unique())
    plot_specs = [
        (
            "spearman_vs_unperturbed",
            "Residual stability after cell removal",
            "Spearman correlation",
        ),
        (
            "top5_jaccard",
            "Top-5 stability after cell removal",
            "Jaccard index",
        ),
        ("case_pair_rank", "State 4-state 10 rank", "Residual rank"),
    ]
    for ax, (metric, title, ylabel) in zip(axes[1], plot_specs):
        for method, color in (("Quotient residual", BLUE), ("Centroid baseline", GREY)):
            means, sds = [], []
            for fraction in fractions:
                values = perturb.loc[
                    (perturb["method"] == method)
                    & (perturb["removed_fraction"] == fraction),
                    metric,
                ].to_numpy(float)
                means.append(values.mean())
                sds.append(values.std(ddof=1))
            ax.errorbar(
                np.asarray(fractions) * 100,
                means,
                yerr=sds,
                marker="o",
                markersize=4,
                linewidth=1.15,
                capsize=2,
                color=color,
                label=method,
            )
        ax.set_xticks(np.asarray(fractions) * 100)
        ax.set_xlabel("Cells removed (%)")
        ax.set_ylabel(ylabel)
        ax.set_title(title, fontweight="bold", pad=8)
    axes[1, 2].invert_yaxis()
    axes[1, 0].legend(loc="lower left")

    panel_letters(axes)
    fig.tight_layout(w_pad=1.6, h_pad=2.0)
    save(fig, FIGDIR / "FigureS10_residual_stability")


def scatter_groups(ax, selected: pd.DataFrame, metric: str, ylabel: str, title: str) -> None:
    rng = np.random.default_rng(8)
    for x, (method, color) in enumerate(
        (("Quotient residual", BLUE), ("Centroid baseline", GREY))
    ):
        values = selected.loc[selected["selection_method"] == method, metric].to_numpy(float)
        ax.scatter(
            np.full(len(values), x) + rng.normal(0, 0.035, len(values)),
            values,
            color=color,
            s=25,
            edgecolor="white",
            linewidth=0.35,
        )
        ax.plot([x - 0.18, x + 0.18], [np.median(values)] * 2, color="black", lw=1.1)
    ax.set_xticks([0, 1], ["Quotient", "Centroid"])
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight="bold", pad=8)


def plot_s11() -> None:
    all_pairs = pd.read_csv(UTILITY / "all_state_pair_utility_metrics.csv")
    selected = pd.read_csv(UTILITY / "top_quotient_vs_centroid_pairs.csv")
    top3 = pd.read_csv(UTILITY / "top3_quotient_residual_pair_cases.csv").head(3)
    fig, axes = plt.subplots(2, 3, figsize=(10.2, 5.3))

    ax = axes[0, 0]
    ax.scatter(
        all_pairs["centroid_residual"],
        all_pairs["quotient_residual"],
        s=19,
        color="#777777",
        alpha=0.82,
        edgecolor="white",
        linewidth=0.3,
    )
    ax.set_xlabel("Centroid-distance residual")
    ax.set_ylabel("Quotient residual")
    ax.set_title(
        "Quotient versus centroid residuals\nSpearman rho = 0.56",
        fontweight="bold",
        pad=8,
    )

    scatter_groups(
        axes[0, 1],
        selected,
        "low_membership_fraction",
        "Low-membership fraction",
        "Low-membership enrichment",
    )
    scatter_groups(
        axes[0, 2],
        selected,
        "rna_atac_silhouette_discrepancy",
        "RNA-ATAC silhouette difference",
        "RNA-ATAC separation difference",
    )

    x = np.arange(len(top3))
    width = 0.34
    ax = axes[1, 0]
    ax.bar(x - width / 2, top3["q_rna"], width, color=BLUE, label="RNA")
    ax.bar(x + width / 2, top3["q_atac"], width, color=ORANGE, label="ATAC")
    ax.set_xticks(x, top3["state_pair"])
    ax.set_ylabel("Normalized quotient distance")
    ax.set_title("Top residual state pairs", fontweight="bold", pad=8)
    ax.legend()

    ax = axes[1, 1]
    ax.bar(
        x,
        top3["quotient_mean_across_seeds"],
        yerr=top3["quotient_sd_across_seeds"],
        color=GREEN,
        capsize=2.5,
        error_kw={"linewidth": 0.8},
    )
    ax.scatter(x, top3["quotient_residual"], color=ORANGE, s=24, zorder=3)
    ax.set_xticks(x, top3["state_pair"])
    ax.set_ylabel("Quotient residual")
    ax.set_title("Cross-run residual stability", fontweight="bold", pad=8)

    ax = axes[1, 2]
    ax.bar(x, top3["quotient_top5_frequency"], color=BLUE)
    ax.set_xticks(x, top3["state_pair"])
    ax.set_ylim(0, 1)
    ax.set_ylabel("Top-5 frequency")
    ax.set_title("Cross-run Top-5 recovery", fontweight="bold", pad=8)

    panel_letters(axes)
    fig.tight_layout(w_pad=1.7, h_pad=2.0)
    save(fig, FIGDIR / "FigureS11_centroid_and_top_pairs")


def main() -> None:
    configure()
    plot_s10()
    plot_s11()


if __name__ == "__main__":
    main()
