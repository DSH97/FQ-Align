import argparse
import gzip
import json
import re
from collections import defaultdict
from pathlib import Path

import anndata as ad
import numpy as np
import pandas as pd
import scipy.sparse as sp


ATTR_RE = re.compile(r'(\S+)\s+"([^"]+)"')


def open_text(path):
    path = str(path)
    if path.endswith(".gz"):
        return gzip.open(path, "rt", encoding="utf-8", errors="ignore")
    return open(path, "r", encoding="utf-8", errors="ignore")


def parse_attrs(attr_text):
    return {k: v for k, v in ATTR_RE.findall(attr_text)}


def clean_gene_id(x):
    return str(x).split(".")[0]


def read_gtf_genes(gtf):
    rows = []
    with open_text(gtf) as fh:
        for line in fh:
            if not line or line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if len(parts) < 9 or parts[2] != "gene":
                continue
            attrs = parse_attrs(parts[8])
            gene_id = attrs.get("gene_id")
            gene_name = attrs.get("gene_name", gene_id)
            if not gene_id:
                continue
            start = int(parts[3]) - 1
            end = int(parts[4])
            strand = parts[6]
            tss = start if strand != "-" else end
            rows.append(
                {
                    "chrom": parts[0],
                    "start": start,
                    "end": end,
                    "strand": strand,
                    "tss": tss,
                    "gene_id": clean_gene_id(gene_id),
                    "gene_name": gene_name,
                }
            )
    return pd.DataFrame(rows)


def pick_col(df, names):
    lower = {c.lower(): c for c in df.columns}
    for name in names:
        if name.lower() in lower:
            return lower[name.lower()]
    return None


def parse_peak_name(name):
    s = str(name)
    m = re.match(r"^(chr[^:]+):(\d+)-(\d+)$", s)
    if not m:
        m = re.match(r"^(chr[^-_]+)[-_](\d+)[-_](\d+)$", s)
    if not m:
        m = re.match(r"^([^:]+):(\d+)-(\d+)$", s)
    if not m:
        return None
    chrom, start, end = m.group(1), int(m.group(2)), int(m.group(3))
    if end < start:
        start, end = end, start
    return chrom, start, end


def peak_table(atac):
    chrom_col = pick_col(atac.var, ["chrom", "chr", "seqnames", "seqname"])
    start_col = pick_col(atac.var, ["start", "chromStart", "chrom_start"])
    end_col = pick_col(atac.var, ["end", "chromEnd", "chrom_end"])
    if chrom_col and start_col and end_col:
        return pd.DataFrame(
            {
                "chrom": atac.var[chrom_col].astype(str).values,
                "start": atac.var[start_col].astype(int).values,
                "end": atac.var[end_col].astype(int).values,
                "peak_index": np.arange(atac.n_vars),
            }
        )

    rows = []
    failed = 0
    for i, name in enumerate(atac.var_names.astype(str)):
        parsed = parse_peak_name(name)
        if parsed is None:
            failed += 1
            continue
        chrom, start, end = parsed
        rows.append((chrom, start, end, i))
    if not rows:
        raise ValueError(
            "Could not parse ATAC peak coordinates from var columns or var_names. "
            "Expected formats like chr1:100-200 or columns chrom/start/end."
        )
    if failed:
        print(f"WARNING: failed to parse {failed} ATAC peaks; they will have no links.")
    return pd.DataFrame(rows, columns=["chrom", "start", "end", "peak_index"])


def build_peak_index(peaks):
    by_chrom = {}
    for chrom, df in peaks.groupby("chrom", sort=False):
        df = df.sort_values("start").reset_index(drop=True)
        by_chrom[chrom] = {
            "start": df["start"].to_numpy(),
            "end": df["end"].to_numpy(),
            "idx": df["peak_index"].to_numpy(),
        }
    return by_chrom


def gene_lookup(rna, genes):
    candidates = []
    for col in ["gene_name", "gene_symbols", "gene_symbol", "symbol", "gene_id", "gene_ids"]:
        if col in rna.var.columns:
            candidates.append(rna.var[col].astype(str).values)
    candidates.append(rna.var_names.astype(str).values)

    by_name = defaultdict(list)
    for i in range(rna.n_vars):
        for values in candidates:
            value = str(values[i])
            by_name[value].append(i)
            by_name[clean_gene_id(value)].append(i)

    gene_rows = []
    for _, row in genes.iterrows():
        hits = []
        for key in (row["gene_name"], row["gene_id"], clean_gene_id(row["gene_id"])):
            hits.extend(by_name.get(str(key), []))
        for i in sorted(set(hits)):
            gene_rows.append((i, row))
    return gene_rows


def main():
    parser = argparse.ArgumentParser(description="Build a gene-peak prior matrix from RNA/ATAC h5ad and GTF.")
    parser.add_argument("--rna", required=True)
    parser.add_argument("--atac", required=True)
    parser.add_argument("--gtf", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--window", type=int, default=150000, help="TSS-centered window in bp.")
    parser.add_argument("--include-gene-body", action="store_true")
    args = parser.parse_args()

    rna = ad.read_h5ad(args.rna, backed="r")
    atac = ad.read_h5ad(args.atac, backed="r")
    genes = read_gtf_genes(args.gtf)
    peaks = peak_table(atac)
    by_chrom = build_peak_index(peaks)

    rows = []
    cols = []
    for gene_i, gene in gene_lookup(rna, genes):
        chrom = gene["chrom"]
        if chrom not in by_chrom:
            alt = chrom[3:] if chrom.startswith("chr") else "chr" + chrom
            chrom = alt if alt in by_chrom else chrom
        if chrom not in by_chrom:
            continue

        left = int(gene["tss"]) - args.window
        right = int(gene["tss"]) + args.window
        if args.include_gene_body:
            left = min(left, int(gene["start"]))
            right = max(right, int(gene["end"]))

        p = by_chrom[chrom]
        stop = np.searchsorted(p["start"], right, side="right")
        if stop == 0:
            continue
        cand = np.arange(stop)
        keep = cand[p["end"][cand] >= left]
        if keep.size:
            peak_idx = p["idx"][keep]
            rows.extend([gene_i] * len(peak_idx))
            cols.extend(peak_idx.tolist())

    data = np.ones(len(rows), dtype=np.float32)
    mat = sp.coo_matrix((data, (rows, cols)), shape=(rna.n_vars, atac.n_vars)).tocsr()
    mat.sum_duplicates()
    mat.data[:] = 1.0
    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    sp.save_npz(args.out, mat)

    meta = {
        "rna": args.rna,
        "atac": args.atac,
        "gtf": args.gtf,
        "out": args.out,
        "shape": list(mat.shape),
        "nnz": int(mat.nnz),
        "window": args.window,
        "include_gene_body": bool(args.include_gene_body),
        "linked_genes": int(np.unique(mat.nonzero()[0]).size) if mat.nnz else 0,
        "linked_peaks": int(np.unique(mat.nonzero()[1]).size) if mat.nnz else 0,
    }
    with open(str(args.out) + ".meta.json", "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2, ensure_ascii=False)
    print(json.dumps(meta, indent=2, ensure_ascii=False))


if __name__ == "__main__":
    main()
